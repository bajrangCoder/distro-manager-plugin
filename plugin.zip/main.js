"use strict";(()=>{var S={$schema:"https://acode.app/schema/plugin/v0.1.0.json",id:"acode.distro-manager",name:"Distro Manager",main:"main.js",version:"1.0.0",repository:"https://github.com/Acode-Foundation/acode-plugin.git",icon:"icon.png",minVersionCode:290,license:"MIT",keywords:["terminal","linux","distro","ubuntu","debian","arch","devcontainer"],price:0,author:{name:"Acode Foundation",email:"",github:"Acode-Foundation"}};var F={alpine:{name:"Alpine Linux",version:"3.21",description:"Lightweight musl-based distro, fast and minimal",icon:"\u{1F3D4}\uFE0F",pkgManager:"apk",urls:{"arm64-v8a":"https://dl-cdn.alpinelinux.org/alpine/v3.21/releases/aarch64/alpine-minirootfs-3.21.0-aarch64.tar.gz","armeabi-v7a":"https://dl-cdn.alpinelinux.org/alpine/v3.21/releases/armhf/alpine-minirootfs-3.21.0-armhf.tar.gz",x86_64:"https://dl-cdn.alpinelinux.org/alpine/v3.21/releases/x86_64/alpine-minirootfs-3.21.0-x86_64.tar.gz"},size:"~3MB",shell:"/bin/sh",isXz:!1},debian:{name:"Debian",version:"trixie",description:"Stable and reliable, the universal operating system",icon:"\u{1F300}",pkgManager:"apt",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.29.0/debian-trixie-aarch64-pd-v4.29.0.tar.xz","armeabi-v7a":"https://github.com/termux/proot-distro/releases/download/v4.29.0/debian-trixie-arm-pd-v4.29.0.tar.xz",x86_64:"https://github.com/termux/proot-distro/releases/download/v4.29.0/debian-trixie-x86_64-pd-v4.29.0.tar.xz"},size:"~35MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},ubuntu:{name:"Ubuntu",version:"25.10 (Questing)",description:"Popular Debian-based distro with apt package manager",icon:"\u{1F7E0}",pkgManager:"apt",urls:{"arm64-v8a":"https://easycli.sh/proot-distro/ubuntu-questing-aarch64-pd-v4.37.0.tar.xz","armeabi-v7a":"https://easycli.sh/proot-distro/ubuntu-questing-arm-pd-v4.37.0.tar.xz",x86_64:"https://easycli.sh/proot-distro/ubuntu-questing-x86_64-pd-v4.37.0.tar.xz"},size:"~58MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},arch:{name:"Arch Linux",version:"latest",description:"Rolling release with pacman, for power users",icon:"\u{1F535}",pkgManager:"pacman",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.34.2/archlinux-aarch64-pd-v4.34.2.tar.xz","armeabi-v7a":"https://github.com/termux/proot-distro/releases/download/v4.34.2/archlinux-arm-pd-v4.34.2.tar.xz",x86_64:"https://github.com/termux/proot-distro/releases/download/v4.34.2/archlinux-x86_64-pd-v4.34.2.tar.xz"},size:"~160MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},fedora:{name:"Fedora",version:"43",description:"Cutting-edge features with dnf package manager",icon:"\u{1F3A9}",pkgManager:"dnf",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.31.0/fedora-aarch64-pd-v4.31.0.tar.xz",x86_64:"https://github.com/termux/proot-distro/releases/download/v4.31.0/fedora-x86_64-pd-v4.31.0.tar.xz"},size:"~38MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},void:{name:"Void Linux",version:"latest",description:"Independent distro with runit and xbps",icon:"\u26AB",pkgManager:"xbps-install",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.29.0/void-aarch64-pd-v4.29.0.tar.xz","armeabi-v7a":"https://github.com/termux/proot-distro/releases/download/v4.29.0/void-arm-pd-v4.29.0.tar.xz",x86_64:"https://github.com/termux/proot-distro/releases/download/v4.29.0/void-x86_64-pd-v4.29.0.tar.xz"},size:"~51MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},opensuse:{name:"openSUSE",version:"tumbleweed",description:"Rolling release with zypper package manager",icon:"\u{1F98E}",pkgManager:"zypper",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.34.2/opensuse-aarch64-pd-v4.34.2.tar.xz",x86_64:"https://github.com/termux/proot-distro/releases/download/v4.34.2/opensuse-x86_64-pd-v4.34.2.tar.xz"},size:"~44MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},manjaro:{name:"Manjaro",version:"latest",description:"User-friendly Arch-based with pacman",icon:"\u{1F7E2}",pkgManager:"pacman",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.34.2/manjaro-aarch64-pd-v4.34.2.tar.xz"},size:"~141MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0}},u=F;var k="distros",N="distro-manager.json";function D(f){return`'${String(f).replace(/'/g,"'\\''")}'`}var R=class{constructor(t){this.filesDir=t,this.distrosPath=`${t}/${k}`,this.configPath=`${t}/${N}`,this.arch=null,this.config={installed:{},activeDistro:null}}async init(){this.arch=await new Promise((t,e)=>{system.getArch(t,e)}),await this.ensureDistrosDir(),await this.loadConfig()}async ensureDistrosDir(){await this.fileExists(this.distrosPath)||await new Promise((e,i)=>{system.mkdirs(this.distrosPath,e,i)})}async loadConfig(){try{if(await this.fileExists(this.configPath)){let e=await Executor.BackgroundExecutor.execute(`cat "${this.configPath}"`);this.config=JSON.parse(e)}}catch(t){console.warn("Failed to load config, using defaults:",t)}}async saveConfig(){let t=JSON.stringify(this.config,null,2);await new Promise((e,i)=>{system.writeText(this.configPath,t,e,i)})}fileExists(t){return new Promise((e,i)=>{system.fileExists(t,!1,s=>{e(s===1)},i)})}getAvailableDistros(){return Object.entries(u).filter(([t,e])=>e.urls[this.arch]).map(([t,e])=>({id:t,...e,installed:!!this.config.installed[t],active:this.config.activeDistro===t}))}getDistroInfo(t){let e=u[t];return e?{id:t,...e,installed:!!this.config.installed[t],active:this.config.activeDistro===t,installPath:`${this.distrosPath}/${t}`}:null}async install(t,e=console.log){let i=u[t];if(!i)throw new Error(`Unknown distro: ${t}`);let s=i.urls[this.arch];if(!s)throw new Error(`Distro ${t} not available for ${this.arch}`);let o=`${this.distrosPath}/${t}`,n=`${o}/rootfs`,c=i.isXz||s.endsWith(".xz"),r=`${t}.tar${c?".xz":".gz"}`;try{if(e(`${i.icon} Installing ${i.name} ${i.version}...`),e(`\u{1F4E6} Size: ${i.size}`),await this.fileExists(o)&&(e("\u{1F9F9} Removing existing installation..."),await Executor.execute(`rm -rf "${o}"`)),await new Promise((a,d)=>{system.mkdirs(n,a,d)}),e("\u2B07\uFE0F Downloading rootfs..."),await new Promise((a,d)=>{cordova.plugin.http.downloadFile(s,{},{},cordova.file.dataDirectory+r,a,m=>{console.error("Download error:",m),d(new Error(`Download failed: ${JSON.stringify(m)}`))})}),e("\u{1F4C2} Extracting rootfs..."),c){e("   \u2192 Installing xz-utils..."),await Executor.execute(`sh -c ${D("apk add --quiet xz 2>/dev/null || true")}`,!0),e("   \u2192 Decompressing xz archive (this may take a few minutes)..."),await Executor.execute(`sh -c ${D(`rm -f "$PREFIX/${t}.tar" && xz -dc "$PREFIX/${r}" > "$PREFIX/${t}.tar"`)}`,!0);let a=`$PREFIX/${t}.tar`;if((await Executor.execute(`test -f "${a}" && echo "yes" || echo "no"`)).trim()!=="yes")throw new Error("Failed to decompress xz archive. The downloaded file may be incomplete or corrupted.");e("   \u2192 Extracting tar archive..."),await Executor.execute(`tar --no-same-owner -xf "${a}" -C "${n}" 2>&1`),await Executor.execute(`rm -f "${a}" "$PREFIX/${r}"`);let m=await Executor.execute(`ls "${n}" 2>/dev/null | wc -l`);if(Number.parseInt(m.trim(),10)===0)throw new Error("Extraction produced no files. The archive may be corrupted or xz decompression failed.")}else e("   \u2192 Extracting gzip archive..."),await Executor.execute(`tar --no-same-owner -xzf "$PREFIX/${r}" -C "${n}" 2>&1`),await Executor.execute(`rm -f "$PREFIX/${r}"`);if(i.isProotDistro){let d=(await Executor.execute(`ls "${n}" 2>/dev/null || echo ""`)).trim().split(`
`).filter(Boolean),m=["bin","etc","lib","lib64","usr","var","root","home","tmp","dev","proc","sys","run","opt","srv","mnt","media","sbin","boot"];if(d.length===1&&!m.includes(d[0])){e("\u{1F4C1} Fixing rootfs structure...");let h=d[0];await Executor.execute(`cd "${n}" && mv "${h}"/* . 2>/dev/null; rmdir "${h}" 2>/dev/null || true`)}}return e("\u2699\uFE0F Configuring DNS..."),await new Promise((a,d)=>{system.writeText(`${n}/etc/resolv.conf`,`nameserver 8.8.8.8
nameserver 8.8.4.4`,a,d)}),this.config.installed[t]={installedAt:new Date().toISOString(),version:i.version},await this.saveConfig(),e(`\u2705 ${i.name} installed successfully!`),!0}catch(a){throw e(`\u274C Installation failed: ${a.message||a}`),await Executor.execute(`rm -rf "${o}" 2>/dev/null || true`),await Executor.execute(`rm -f "$PREFIX/${r}" "$PREFIX/${t}.tar" 2>/dev/null || true`),a}}async uninstall(t,e=console.log){let i=u[t];if(!i)throw new Error(`Unknown distro: ${t}`);let s=`${this.distrosPath}/${t}`;e(`\u{1F5D1}\uFE0F Uninstalling ${i.name}...`),this.config.activeDistro===t&&(this.config.activeDistro=null),await Executor.execute(`rm -rf "${s}"`),delete this.config.installed[t],await this.saveConfig(),e(`\u2705 ${i.name} uninstalled`)}async execInDistro(t,e){let i=u[t];if(!i)throw new Error(`Unknown distro: ${t}`);let s=`${this.distrosPath}/${t}/rootfs`,o=this.generateProotScript(s,e,i.shell);return await Executor.execute(o)}async startShell(t,e){let i=u[t];if(!i)throw new Error(`Unknown distro: ${t}`);if(!this.config.installed[t])throw new Error(`${i.name} is not installed`);let s=`${this.distrosPath}/${t}/rootfs`,o=this.generateProotScript(s,i.shell,i.shell);this.config.activeDistro=t,await this.saveConfig();let n=await Executor.start("sh",e,!1);return await Executor.write(n,`${o}
`),n}generateProotScript(t,e,i="/bin/sh"){return`
export LD_LIBRARY_PATH=$PREFIX
export PROOT_TMP_DIR=$PREFIX/tmp

mkdir -p "$PREFIX/tmp"

if [ -f "$NATIVE_DIR/libproot.so" ]; then
  export PROOT_LOADER="$NATIVE_DIR/libproot.so"
fi
if [ -f "$NATIVE_DIR/libproot32.so" ]; then
  export PROOT_LOADER32="$NATIVE_DIR/libproot32.so"
fi
export PROOT="$NATIVE_DIR/libproot-xed.so"

ARGS="--kill-on-exit"

for mnt in /apex /odm /product /system /system_ext /vendor /linkerconfig/ld.config.txt; do
  [ -e "$mnt" ] && ARGS="$ARGS -b $(realpath $mnt)"
done

ARGS="$ARGS -b /sdcard -b /storage -b /dev -b /data -b /proc -b /sys"
ARGS="$ARGS -b /dev/urandom:/dev/random"
ARGS="$ARGS -b $PREFIX/public:/public"
ARGS="$ARGS -b $PREFIX/public:/home"
ARGS="$ARGS -b $PREFIX/public:/root"
ARGS="$ARGS -r ${t}"
ARGS="$ARGS -0 --link2symlink --sysvipc -L"
ARGS="$ARGS -w /root"

$PROOT $ARGS ${i} -c "${e.replace(/"/g,'\\"')}"
`}async getInstalledSize(t){let e=`${this.distrosPath}/${t}`;try{return(await Executor.execute(`du -sh "${e}" 2>/dev/null | cut -f1`)).trim()||"Unknown"}catch{return"Unknown"}}},y=R;var O=acode.require("confirm"),g=acode.require("alert"),x=acode.require("select"),T=acode.require("loader"),$={INSTALL:"distro-manager.install",UNINSTALL:"distro-manager.uninstall",OPEN_SHELL:"distro-manager.shell",LIST:"distro-manager.list",INFO:"distro-manager.info"},C=43130,I=8;function X(f){return`'${String(f).replace(/'/g,"'\\''")}'`}var v=class{constructor(){this.manager=null,this.baseUrl="",this.filesDir=""}async init(){this.filesDir=await new Promise((t,e)=>{system.getFilesDir(t,e)}),this.manager=new y(this.filesDir),await this.manager.init(),this.registerCommands()}registerCommands(){let{commands:t}=editorManager.editor;t.addCommand({name:$.INSTALL,description:"Distro Manager: Install Distribution",exec:()=>this.showInstallMenu()}),t.addCommand({name:$.UNINSTALL,description:"Distro Manager: Uninstall Distribution",exec:()=>this.showUninstallMenu()}),t.addCommand({name:$.OPEN_SHELL,description:"Distro Manager: Open Shell",exec:()=>this.showShellMenu()}),t.addCommand({name:$.LIST,description:"Distro Manager: List Distributions",exec:()=>this.showDistroList()}),t.addCommand({name:$.INFO,description:"Distro Manager: Distribution Info",exec:()=>this.showDistroInfo()})}async showInstallMenu(){let t=this.manager.getAvailableDistros().filter(s=>!s.installed);if(t.length===0){g("Distro Manager","All available distributions are already installed! \u{1F389}");return}let e=t.map(s=>[s.id,`${s.icon} ${s.name} ${s.version}`,`${s.description} (${s.size})`]),i=await x("Select Distribution to Install",e,{textTransform:!1});i&&await this.installDistro(i)}async installDistro(t){let e=u[t];if(!e)return;let i=`
      <div style="text-align: left;">
        <p><strong>${e.icon} ${e.name} ${e.version}</strong></p>
        <br>
        <p>\u{1F4E6} <strong>Size:</strong> ${e.size}</p>
        <p>\u{1F4CB} <strong>Package Manager:</strong> ${e.pkgManager}</p>
        <br>
        <p style="color: #888;">This may take a few minutes depending on your connection.</p>
      </div>
    `;if(!await O("Install Distribution",i,!0))return;let o=T.create("Installing...","",{timeout:0}),n=[],c=r=>{n.push(r),o.setMessage(r),console.log(`[DistroManager] ${r}`)};try{await this.manager.install(t,c),await this.createDistroInitScript(t,{force:!0}),o.destroy();let r=`
        <div style="text-align: center;">
          <p style="font-size: 1.2em;">${e.icon} <strong>${e.name}</strong></p>
          <p style="color: #4CAF50;">\u2713 Installed successfully!</p>
          <br>
          <p style="color: #888; font-size: 0.9em;">
            Use <strong>"Distro Manager: Open Shell"</strong><br>from the command palette to start.
          </p>
        </div>
      `;g("Installation Complete",r)}catch(r){o.destroy();let a=r.message||String(r),d=`
        <div style="text-align: left;">
          <p style="color: #F44336;">\u274C Failed to install ${e.name}</p>
          <br>
          <p><strong>Error:</strong></p>
          <p style="font-family: monospace; font-size: 0.85em; color: #888;">${a}</p>
          <br>
          <p><strong>Recent logs:</strong></p>
          <pre style="font-size: 0.8em; color: #666; overflow-x: auto;">${n.slice(-5).join("<br>")}</pre>
        </div>
      `;g("Installation Failed",d)}}async ensureDistroInitScript(t){let e=this.manager.config.installed[t],i=`${this.manager.distrosPath}/${t}/init-distro.sh`,o=`${`${this.manager.distrosPath}/${t}/rootfs`}/etc/acode-initrc`;return e?.initScriptVersion===I&&await this.manager.fileExists(i)&&await this.manager.fileExists(o)?i:this.createDistroInitScript(t,{force:!0})}async createDistroInitScript(t,{force:e=!1}={}){let i=u[t],s=`${this.manager.distrosPath}/${t}/rootfs`,o=`${this.manager.distrosPath}/${t}`,n=`${this.manager.distrosPath}/${t}/init-distro.sh`,c=`${s}/etc/acode-initrc`,r=`${o}/last-launch.log`;if(!e&&await this.manager.fileExists(n))return n;let a=i.name.toLowerCase().replace(/\s+/g,""),d=`# Acode ${i.name} Shell Configuration
export HOME=/root
export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:/system/bin
export TERM=xterm-256color
export LANG=C.UTF-8
export SHELL=${i.shell}

# Source system profiles if they exist
[ -f /etc/profile ] && . /etc/profile
[ -f /etc/bash.bashrc ] && . /etc/bash.bashrc
[ -f ~/.bashrc ] && . ~/.bashrc

# Unset PROMPT_COMMAND to prevent it overriding our prompt
unset PROMPT_COMMAND

# Color prompt: user@distro:path$
if [ -n "$BASH_VERSION" ]; then
  PS1='\\[\\033[1;32m\\]\\u\\[\\033[0m\\]@\\[\\033[1;35m\\]${a}\\[\\033[0m\\]:\\[\\033[1;34m\\]\\w\\[\\033[0m\\]\\$ '
else
  # POSIX sh
  PS1='\\033[1;32m$(whoami 2>/dev/null || echo root)\\033[0m@\\033[1;35m${a}\\033[0m:\\033[1;34m$PWD\\033[0m# '
fi

# Show welcome message
if [ -z "$ACODE_MOTD_SHOWN" ]; then
  export ACODE_MOTD_SHOWN=1
  printf "\\033[1;35m  \u{1F680} ${i.name} environment loaded successfully.\\033[0m\\n"
  printf "\\033[1;30m  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\\033[0m\\n"
  printf "   \\033[1;32m\u2022 Package Manager :\\033[0m \\033[1;36m${i.pkgManager}\\033[0m\\n"
  printf "   \\033[1;32m\u2022 Home Directory  :\\033[0m \\033[1;36m\\$HOME\\033[0m\\n"
  printf "   \\033[1;32m\u2022 Quick Editor    :\\033[0m Run \\033[1;33macode <file>\\033[0m to edit\\n"
  printf "\\033[1;30m  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\\033[0m\\n\\n"
fi

cd "$HOME" 2>/dev/null || cd /root 2>/dev/null || cd /
`,m=`${s}/etc/profile`;try{let l="";await this.manager.fileExists(m)&&(l=await Executor.BackgroundExecutor.execute(`cat "${m}"`));let E="# >>> Acode Distro Init Start >>>",b="# <<< Acode Distro Init End <<<",A=l.indexOf(E),P=l.indexOf(b);A!==-1&&P!==-1&&(l=l.slice(0,A)+l.slice(P+b.length));let M=`
${E}
# Acode ${i.name} Shell Configuration
export HOME=/root
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/system/bin
export TERM=xterm-256color
export LANG=C.UTF-8
export SHELL=${i.shell}

# Unset PROMPT_COMMAND to prevent it overriding our prompt
unset PROMPT_COMMAND

if [ -n "$BASH_VERSION" ]; then
  PS1='\\[\\033[1;32m\\]\\u\\[\\033[0m\\]@\\[\\033[1;35m\\]${a}\\[\\033[0m\\]:\\[\\033[1;34m\\]\\w\\[\\033[0m\\]\\$ '
else
  PS1='\\033[1;32m$(whoami 2>/dev/null || echo root)\\033[0m@\\033[1;35m${a}\\033[0m:\\033[1;34m$PWD\\033[0m# '
fi

if [ -z "$ACODE_MOTD_SHOWN" ]; then
  export ACODE_MOTD_SHOWN=1
  printf "\\033[1;35m  \u{1F680} ${i.name} environment loaded successfully.\\033[0m\\n"
  printf "\\033[1;30m  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\\033[0m\\n"
  printf "   \\033[1;32m\u2022 Package Manager :\\033[0m \\033[1;36m${i.pkgManager}\\033[0m\\n"
  printf "   \\033[1;32m\u2022 Home Directory  :\\033[0m \\033[1;36m\\$HOME\\033[0m\\n"
  printf "   \\033[1;32m\u2022 Quick Editor    :\\033[0m Run \\033[1;33macode <file>\\033[0m to edit\\n"
  printf "\\033[1;30m  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\\033[0m\\n\\n"
fi

cd "\\$HOME" 2>/dev/null || cd /root 2>/dev/null || cd /
${b}
`;l=l.trim()+`
`+M,await new Promise((_,G)=>{system.writeText(m,l,_,G)})}catch(l){console.warn("[DistroManager] Failed to update /etc/profile:",l)}let h=`#!/bin/sh
export LD_LIBRARY_PATH=$PREFIX
export PROOT_TMP_DIR=$PREFIX/tmp
export ENV=/etc/acode-initrc
LOG_FILE="${r}"

log() {
  printf '%s %s\\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG_FILE"
}

: > "$LOG_FILE"
log "starting ${i.name} launcher"
log "PREFIX=$PREFIX"
log "NATIVE_DIR=$NATIVE_DIR"
log "FDROID=$FDROID"

mkdir -p "$PREFIX/tmp"
mkdir -p "$PREFIX/public"
mkdir -p "${s}/tmp"

if [ -f "$NATIVE_DIR/libproot.so" ]; then
  export PROOT_LOADER="$NATIVE_DIR/libproot.so"
fi
if [ -f "$NATIVE_DIR/libproot32.so" ]; then
  export PROOT_LOADER32="$NATIVE_DIR/libproot32.so"
fi

if [ "$FDROID" = "true" ]; then
  export PROOT="$PREFIX/libproot-xed.so"
  chmod +x $PREFIX/*
else
  if [ -e "$PREFIX/libtalloc.so.2" ] || [ -L "$PREFIX/libtalloc.so.2" ]; then
    rm -f "$PREFIX/libtalloc.so.2"
  fi
  ln -sf "$NATIVE_DIR/libtalloc.so" "$PREFIX/libtalloc.so.2"
  export PROOT="$NATIVE_DIR/libproot-xed.so"
fi

log "PROOT=$PROOT"
log "PROOT_LOADER=$PROOT_LOADER"
log "PROOT_LOADER32=$PROOT_LOADER32"

ARGS="--kill-on-exit"

for mnt in /apex /odm /product /system /system_ext /vendor /linkerconfig/ld.config.txt /linkerconfig/com.android.art/ld.config.txt /plat_property_contexts /property_contexts; do
  [ -e "$mnt" ] && ARGS="$ARGS -b $(realpath $mnt)"
done

ARGS="$ARGS -b /sdcard"
ARGS="$ARGS -b /storage"
ARGS="$ARGS -b /dev"
ARGS="$ARGS -b /data"
ARGS="$ARGS -b /dev/urandom:/dev/random"
ARGS="$ARGS -b /proc"
ARGS="$ARGS -b /sys"
ARGS="$ARGS -b $PREFIX"
ARGS="$ARGS -b $PREFIX/public:/public"
ARGS="$ARGS -b $PREFIX/public:/home"
ARGS="$ARGS -b $PREFIX/public:/root"
ARGS="$ARGS -b ${s}/tmp:/dev/shm"

[ -e "/proc/self/fd" ] && ARGS="$ARGS -b /proc/self/fd:/dev/fd"
[ -e "/proc/self/fd/0" ] && ARGS="$ARGS -b /proc/self/fd/0:/dev/stdin"
[ -e "/proc/self/fd/1" ] && ARGS="$ARGS -b /proc/self/fd/1:/dev/stdout"
[ -e "/proc/self/fd/2" ] && ARGS="$ARGS -b /proc/self/fd/2:/dev/stderr"

ARGS="$ARGS -r ${s}"
ARGS="$ARGS -0"
ARGS="$ARGS --link2symlink"
ARGS="$ARGS --sysvipc"
ARGS="$ARGS -L"
ARGS="$ARGS -w /root"

DISTRO_SHELL="${i.shell}"
SHELL_ARGS="-l"

if [ ! -e "${s}$DISTRO_SHELL" ] && [ -e "${s}/usr/bin/bash" ]; then
  DISTRO_SHELL="/usr/bin/bash"
fi

case "$DISTRO_SHELL" in
  */bash)
    SHELL_ARGS="--rcfile /etc/acode-initrc -i"
    ;;
esac

if [ ! -x "$PROOT" ]; then
  echo "proot executable is missing or not executable: $PROOT" >&2
  exit 126
fi

if [ ! -e "${s}$DISTRO_SHELL" ]; then
  echo "shell not found in rootfs: $DISTRO_SHELL" >&2
  log "shell not found in rootfs: $DISTRO_SHELL"
  exit 127
fi

log "DISTRO_SHELL=$DISTRO_SHELL"
log "SHELL_ARGS=$SHELL_ARGS"
log "ARGS=$ARGS"
log "executing proot"

exec $PROOT $ARGS "$DISTRO_SHELL" $SHELL_ARGS
`;await new Promise((l,p)=>{system.writeText(c,d,l,p)}),await new Promise((l,p)=>{system.writeText(n,h,l,p)});let w=`${s}/usr/local/bin`;await this.manager.fileExists(w)||await new Promise((l,p)=>{system.mkdirs(w,l,p)});let L=`#!/bin/sh
# acode - Open files/folders in Acode editor from inside distro
if [ $# -eq 0 ]; then
  printf '\\e]7777;open;folder;.\\a'
  exit 0
fi
for arg in "$@"; do
  if [ -d "$arg" ]; then
    printf '\\e]7777;open;folder;%s\\a' "$(realpath "$arg")"
  else
    printf '\\e]7777;open;file;%s\\a' "$(realpath "$arg")"
  fi
done
`;return await new Promise((l,p)=>{system.writeText(`${w}/acode`,L,l,p)}),await new Promise((l,p)=>{system.setExec(`${w}/acode`,!0,l,p)}),await new Promise((l,p)=>{system.setExec(n,!0,l,p)}),this.manager.config.installed[t]&&(this.manager.config.installed[t].initScriptVersion=I,await this.manager.saveConfig()),n}async showUninstallMenu(){let t=this.manager.getAvailableDistros().filter(r=>r.installed);if(t.length===0){g("Distro Manager","No distributions installed yet.");return}let e=await Promise.all(t.map(async r=>{let a=await this.manager.getInstalledSize(r.id);return[r.id,`${r.icon} ${r.name}`,`Size: ${a}`]})),i=await x("Select Distribution to Uninstall",e,{textTransform:!1});if(!i)return;let s=u[i],o=`
      <div style="text-align: left;">
        <p>\u26A0\uFE0F <strong>Uninstall ${s.name}?</strong></p>
        <br>
        <p style="color: #F44336;">This will permanently delete all data in this distribution including:</p>
        <ul style="color: #888; margin-left: 1em;">
          <li>Installed packages</li>
          <li>User files and configurations</li>
          <li>All custom modifications</li>
        </ul>
      </div>
    `;if(!await O("Uninstall Distribution",o,!0))return;let c=T.create("Uninstalling...","",{timeout:0});try{await this.manager.uninstall(i,r=>c.setMessage(r)),c.destroy(),g("Uninstalled",`${s.icon} ${s.name} has been removed.`)}catch(r){c.destroy(),g("Error",`Failed to uninstall: ${r.message||r}`)}}async showShellMenu(){let t=this.manager.getAvailableDistros().filter(s=>s.installed);if(t.length===0){g("No Distributions",`
        <div style="text-align: center;">
          <p>\u{1F4E6} No distributions installed</p>
          <br>
          <p style="color: #888; font-size: 0.9em;">
            Use <strong>"Distro Manager: Install Distribution"</strong><br>
            from the command palette to get started.
          </p>
        </div>
      `);return}let e=t.map(s=>[s.id,`${s.icon} ${s.name} ${s.version}`,s.active?"\u{1F7E2} active":""]),i=await x("Select Distribution",e,{textTransform:!1});i&&await this.openTerminal(i)}async openTerminal(t){if(u[t])try{await this.ensureDistroInitScript(t),await this.startDistroServer(t)||console.warn("[DistroManager] Failed to start PTY server")}catch(i){console.error("[DistroManager] Failed to open terminal:",i),acode.alert("Error",`Failed to start shell: ${i.message||i}`)}}async startDistroServer(t){let e=await this.ensureDistroInitScript(t),i=C+Object.keys(u).indexOf(t);try{if(await this.checkServerRunning(i))return console.log(`[DistroManager] Server already running on port ${i}`),await this.showTerminalOptions(t,i),i;let o=`${this.filesDir}/axs`;if(!await this.manager.fileExists(o))return acode.alert("AXS Not Found",`
          <div style="text-align: left;">
            <p>\u26A0\uFE0F <strong>AXS Server Not Found</strong></p>
            <br>
            <p style="color: #888;">
              The PTY server binary is not installed.<br><br>
              Please open Acode's built-in terminal first to install the required components.
            </p>
          </div>
        `),null;await new Promise((m,h)=>{system.setExec(o,!0,m,h)}),await new Promise((m,h)=>{system.setExec(e,!0,m,h)});let c=await Executor.start("sh",(m,h)=>{console.log(`[DistroManager AXS] ${m}: ${h}`)}),a=`
chmod +x "$PREFIX/axs" ${X(e)}
LINKER="/system/bin/linker64"
ARCH="$(uname -m)"
if [ "$ARCH" != "aarch64" ] && [ "$ARCH" != "x86_64" ]; then
  LINKER="/system/bin/linker"
fi
exec "$LINKER" "$PREFIX/axs" -p ${i} -c "sh ${e}"
`;return await Executor.write(c,`${a}
`),await new Promise(m=>setTimeout(m,3e3)),await this.checkServerRunning(i)?(this.manager.config.activeDistro=t,await this.manager.saveConfig(),await this.showTerminalOptions(t,i),i):(console.warn("[DistroManager] Server may not have started correctly"),await this.showTerminalOptions(t,i),i)}catch(s){throw console.error("[DistroManager] Failed to start server:",s),s}}async showTerminalOptions(t,e){let i=u[t],s=acode.require("acodex"),o=acode.require("terminal"),n=[["acodex","\u{1F5A5}\uFE0F Open in AcodeX Terminal","Connect using AcodeX plugin (recommended)"],["builtin","\u{1F4DF} Open in Built-in Terminal","Use Acode terminal UI directly"],["log","\u{1F4C4} Show Launch Log","View the last distro startup log"],["info","\u2139\uFE0F Show Server Info","View connection details only"]];s||(n[0][2]="\u26A0\uFE0F AcodeX plugin not installed"),o||(n[1][2]="\u26A0\uFE0F Built-in terminal not available");let c=await x("Terminal Option",n,{textTransform:!1});if(c)if(c==="acodex"){if(!s){let r=`
          <div style="text-align: left;">
            <p>\u26A0\uFE0F <strong>AcodeX Not Found</strong></p>
            <br>
            <p style="color: #888;">
              The AcodeX terminal plugin is not installed.<br><br>
              Please install AcodeX from the plugin store to use this feature.
            </p>
            <br>
            <p style="font-size: 0.9em;">
              <strong>Server is still running on port:</strong> <code>${e}</code>
            </p>
          </div>
        `;acode.alert("AcodeX Not Found",r);return}try{s.isTerminalOpened()&&(s.closeTerminal(),await new Promise(r=>setTimeout(r,300))),await s.openTerminal(270,e)}catch(r){console.error("[DistroManager] Failed to open AcodeX:",r),acode.alert("Error",`Failed to connect AcodeX: ${r.message||r}`)}}else if(c==="builtin"){if(!o){acode.alert("Error","Built-in terminal is not available.");return}try{let r=await this.createDistroSession(e);await o.create({name:`${i.icon} ${i.name}`,port:e,pid:r}),this.manager.config.activeDistro=t,await this.manager.saveConfig()}catch(r){console.error("[DistroManager] Built-in terminal failed:",r),acode.alert("Error",`Failed to open built-in terminal: ${r.message||r}`)}}else if(c==="log")await this.showLaunchLog(t);else{let r=`
        <div style="text-align: left;">
          <p>${i.icon} <strong>${i.name}</strong> PTY server running</p>
          <br>
          <p><strong>Port:</strong> <code>${e}</code></p>
          <br>
          <p><strong>Connect using:</strong></p>
          <ul style="margin-left: 1em; color: #888;">
            <li>AcodeX terminal plugin (recommended)</li>
            <li>Any WebSocket terminal client</li>
          </ul>
          <br>
          <p style="font-size: 0.85em; color: #666;">
            <strong>WebSocket:</strong> <code>ws://localhost:${e}/terminals/&lt;pid&gt;</code><br>
            <strong>Create session:</strong> <code>POST http://localhost:${e}/terminals</code>
          </p>
        </div>
      `;acode.alert(`${i.icon} Server Running`,r)}}async showLaunchLog(t){let e=u[t],i=`${this.manager.distrosPath}/${t}/last-launch.log`,s="";try{s=await this.manager.fileExists(i)?await Executor.BackgroundExecutor.execute(`cat "${i}"`):"No launch log has been written yet."}catch(n){s=`Failed to read launch log: ${n.message||n}`}let o=String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");g(`${e.icon} ${e.name} Launch Log`,`<pre style="text-align:left; white-space:pre-wrap; font-size:0.8em; max-height:60vh; overflow:auto;">${o}</pre>`)}async createDistroSession(t){let e=await new Promise((i,s)=>{cordova.plugin.http.sendRequest(`http://localhost:${t}/terminals`,{method:"POST",responseType:"text",serializer:"json",data:{cols:80,rows:24}},i,o=>s(new Error(o.error||"Failed to create session")))});if(e.status<200||e.status>=300)throw new Error(`Failed to create session: HTTP ${e.status}`);return e.data.trim()}async checkServerRunning(t){try{return(await fetch(`http://localhost:${t}/`,{method:"GET",signal:AbortSignal.timeout(1e3)})).ok}catch{return!1}}async showDistroList(){let t=this.manager.getAvailableDistros(),e=t.filter(o=>o.installed),i=t.filter(o=>!o.installed),s='<div style="text-align: left;">';if(s+="<p><strong>\u{1F4E6} Installed:</strong></p>",e.length>0){s+='<ul style="margin-left: 1em; margin-bottom: 1em;">';for(let o of e){let n=await this.manager.getInstalledSize(o.id);s+=`<li>${o.icon} ${o.name} ${o.version} <span style="color: #888;">(${n})</span></li>`}s+="</ul>"}else s+='<p style="color: #888; margin-left: 1em;">None</p><br>';s+="<p><strong>\u{1F4E5} Available:</strong></p>",s+='<ul style="margin-left: 1em;">';for(let o of i)s+=`<li>${o.icon} ${o.name} ${o.version} <span style="color: #888;">(${o.size})</span></li>`;s+="</ul></div>",g("Distributions",s)}async showDistroInfo(){let e=this.manager.getAvailableDistros().map(a=>[a.id,`${a.icon} ${a.name}`,a.installed?"\u2713 Installed":"Not installed"]),i=await x("Select Distribution",e,{textTransform:!1});if(!i)return;let s=this.manager.getDistroInfo(i),o="N/A";s.installed&&(o=await this.manager.getInstalledSize(i));let n=s.installed?"#4CAF50":"#888",c=s.installed?`\u2705 Installed (${o})`:"\u274C Not installed",r=`
      <div style="text-align: left;">
        <p style="font-size: 1.2em;">${s.icon} <strong>${s.name}</strong> ${s.version}</p>
        <p style="color: #888; margin-bottom: 1em;">${s.description}</p>
        
        <table style="width: 100%; font-size: 0.9em;">
          <tr><td style="color: #888;">Package Manager</td><td><strong>${s.pkgManager}</strong></td></tr>
          <tr><td style="color: #888;">Download Size</td><td>${s.size}</td></tr>
          <tr><td style="color: #888;">Status</td><td style="color: ${n};">${c}</td></tr>
          ${s.active?'<tr><td style="color: #888;">State</td><td style="color: #4CAF50;">\u{1F7E2} Active</td></tr>':""}
        </table>
        
        <p style="margin-top: 1em; font-size: 0.8em; color: #666;">
          <strong>Path:</strong> ${s.installPath}
        </p>
      </div>
    `;g("Distribution Info",r)}destroy(){let{commands:t}=editorManager.editor;Object.values($).forEach(e=>{t.removeCommand(e)})}};if(window.acode){let f=new v;acode.setPluginInit(S.id,async t=>{t.endsWith("/")||(t+="/"),f.baseUrl=t,await f.init()}),acode.setPluginUnmount(S.id,()=>{f.destroy()})}})();
