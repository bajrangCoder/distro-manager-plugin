"use strict";(()=>{var ee,x,Re,Ke,F,ye,ke,Ee,ne,W,X,Pe,ce,se,ae,Ze,J={},K=[],et=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,te=Array.isArray;function O(t,e){for(var r in e)t[r]=e[r];return t}function ue(t){t&&t.parentNode&&t.parentNode.removeChild(t)}function c(t,e,r){var o,i,n,a={};for(n in e)n=="key"?o=e[n]:n=="ref"?i=e[n]:a[n]=e[n];if(arguments.length>2&&(a.children=arguments.length>3?ee.call(arguments,2):r),typeof t=="function"&&t.defaultProps!=null)for(n in t.defaultProps)a[n]===void 0&&(a[n]=t.defaultProps[n]);return Q(t,a,o,i,null)}function Q(t,e,r,o,i){var n={type:t,props:e,key:r,ref:o,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:i??++Re,__i:-1,__u:0};return i==null&&x.vnode!=null&&x.vnode(n),n}function G(t){return t.children}function Y(t,e){this.props=t,this.context=e}function U(t,e){if(e==null)return t.__?U(t.__,t.__i+1):null;for(var r;e<t.__k.length;e++)if((r=t.__k[e])!=null&&r.__e!=null)return r.__e;return typeof t.type=="function"?U(t):null}function tt(t){if(t.__P&&t.__d){var e=t.__v,r=e.__e,o=[],i=[],n=O({},e);n.__v=e.__v+1,x.vnode&&x.vnode(n),de(t.__P,n,e,t.__n,t.__P.namespaceURI,32&e.__u?[r]:null,o,r??U(e),!!(32&e.__u),i),n.__v=e.__v,n.__.__k[n.__i]=n,Le(o,n,i),e.__e=e.__=null,n.__e!=r&&Ae(n)}}function Ae(t){if((t=t.__)!=null&&t.__c!=null)return t.__e=t.__c.base=null,t.__k.some(function(e){if(e!=null&&e.__e!=null)return t.__e=t.__c.base=e.__e}),Ae(t)}function we(t){(!t.__d&&(t.__d=!0)&&F.push(t)&&!Z.__r++||ye!=x.debounceRendering)&&((ye=x.debounceRendering)||ke)(Z)}function Z(){try{for(var t,e=1;F.length;)F.length>e&&F.sort(Ee),t=F.shift(),e=F.length,tt(t)}finally{F.length=Z.__r=0}}function De(t,e,r,o,i,n,a,u,m,l,f){var s,p,_,y,R,g,h,v=o&&o.__k||K,E=e.length;for(m=rt(r,e,v,m,E),s=0;s<E;s++)(_=r.__k[s])!=null&&(p=_.__i!=-1&&v[_.__i]||J,_.__i=s,g=de(t,_,p,i,n,a,u,m,l,f),y=_.__e,_.ref&&p.ref!=_.ref&&(p.ref&&_e(p.ref,null,_),f.push(_.ref,_.__c||y,_)),R==null&&y!=null&&(R=y),(h=!!(4&_.__u))||p.__k===_.__k?(m=Te(_,m,t,h),h&&p.__e&&(p.__e=null)):typeof _.type=="function"&&g!==void 0?m=g:y&&(m=y.nextSibling),_.__u&=-7);return r.__e=R,m}function rt(t,e,r,o,i){var n,a,u,m,l,f=r.length,s=f,p=0;for(t.__k=new Array(i),n=0;n<i;n++)(a=e[n])!=null&&typeof a!="boolean"&&typeof a!="function"?(typeof a=="string"||typeof a=="number"||typeof a=="bigint"||a.constructor==String?a=t.__k[n]=Q(null,a,null,null,null):te(a)?a=t.__k[n]=Q(G,{children:a},null,null,null):a.constructor===void 0&&a.__b>0?a=t.__k[n]=Q(a.type,a.props,a.key,a.ref?a.ref:null,a.__v):t.__k[n]=a,m=n+p,a.__=t,a.__b=t.__b+1,u=null,(l=a.__i=ot(a,r,m,s))!=-1&&(s--,(u=r[l])&&(u.__u|=2)),u==null||u.__v==null?(l==-1&&(i>f?p--:i<f&&p++),typeof a.type!="function"&&(a.__u|=4)):l!=m&&(l==m-1?p--:l==m+1?p++:(l>m?p--:p++,a.__u|=4))):t.__k[n]=null;if(s)for(n=0;n<f;n++)(u=r[n])!=null&&(2&u.__u)==0&&(u.__e==o&&(o=U(u)),Ne(u,u));return o}function Te(t,e,r,o){var i,n;if(typeof t.type=="function"){for(i=t.__k,n=0;i&&n<i.length;n++)i[n]&&(i[n].__=t,e=Te(i[n],e,r,o));return e}t.__e!=e&&(o&&(e&&t.type&&!e.parentNode&&(e=U(t)),r.insertBefore(t.__e,e||null)),e=t.__e);do e=e&&e.nextSibling;while(e!=null&&e.nodeType==8);return e}function ot(t,e,r,o){var i,n,a,u=t.key,m=t.type,l=e[r],f=l!=null&&(2&l.__u)==0;if(l===null&&u==null||f&&u==l.key&&m==l.type)return r;if(o>(f?1:0)){for(i=r-1,n=r+1;i>=0||n<e.length;)if((l=e[a=i>=0?i--:n++])!=null&&(2&l.__u)==0&&u==l.key&&m==l.type)return a}return-1}function $e(t,e,r){e[0]=="-"?t.setProperty(e,r??""):t[e]=r==null?"":typeof r!="number"||et.test(e)?r:r+"px"}function q(t,e,r,o,i){var n,a;e:if(e=="style")if(typeof r=="string")t.style.cssText=r;else{if(typeof o=="string"&&(t.style.cssText=o=""),o)for(e in o)r&&e in r||$e(t.style,e,"");if(r)for(e in r)o&&r[e]==o[e]||$e(t.style,e,r[e])}else if(e[0]=="o"&&e[1]=="n")n=e!=(e=e.replace(Pe,"$1")),a=e.toLowerCase(),e=a in t||e=="onFocusOut"||e=="onFocusIn"?a.slice(2):e.slice(2),t.l||(t.l={}),t.l[e+n]=r,r?o?r[X]=o[X]:(r[X]=ce,t.addEventListener(e,n?ae:se,n)):t.removeEventListener(e,n?ae:se,n);else{if(i=="http://www.w3.org/2000/svg")e=e.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(e!="width"&&e!="height"&&e!="href"&&e!="list"&&e!="form"&&e!="tabIndex"&&e!="download"&&e!="rowSpan"&&e!="colSpan"&&e!="role"&&e!="popover"&&e in t)try{t[e]=r??"";break e}catch{}typeof r=="function"||(r==null||r===!1&&e[4]!="-"?t.removeAttribute(e):t.setAttribute(e,e=="popover"&&r==1?"":r))}}function Se(t){return function(e){if(this.l){var r=this.l[e.type+t];if(e[W]==null)e[W]=ce++;else if(e[W]<r[X])return;return r(x.event?x.event(e):e)}}}function de(t,e,r,o,i,n,a,u,m,l){var f,s,p,_,y,R,g,h,v,E,T,L,N,C,I,d=e.type;if(e.constructor!==void 0)return null;128&r.__u&&(m=!!(32&r.__u),n=[u=e.__e=r.__e]),(f=x.__b)&&f(e);e:if(typeof d=="function")try{if(h=e.props,v=d.prototype&&d.prototype.render,E=(f=d.contextType)&&o[f.__c],T=f?E?E.props.value:f.__:o,r.__c?g=(s=e.__c=r.__c).__=s.__E:(v?e.__c=s=new d(h,T):(e.__c=s=new Y(h,T),s.constructor=d,s.render=nt),E&&E.sub(s),s.state||(s.state={}),s.__n=o,p=s.__d=!0,s.__h=[],s._sb=[]),v&&s.__s==null&&(s.__s=s.state),v&&d.getDerivedStateFromProps!=null&&(s.__s==s.state&&(s.__s=O({},s.__s)),O(s.__s,d.getDerivedStateFromProps(h,s.__s))),_=s.props,y=s.state,s.__v=e,p)v&&d.getDerivedStateFromProps==null&&s.componentWillMount!=null&&s.componentWillMount(),v&&s.componentDidMount!=null&&s.__h.push(s.componentDidMount);else{if(v&&d.getDerivedStateFromProps==null&&h!==_&&s.componentWillReceiveProps!=null&&s.componentWillReceiveProps(h,T),e.__v==r.__v||!s.__e&&s.shouldComponentUpdate!=null&&s.shouldComponentUpdate(h,s.__s,T)===!1){e.__v!=r.__v&&(s.props=h,s.state=s.__s,s.__d=!1),e.__e=r.__e,e.__k=r.__k,e.__k.some(function(b){b&&(b.__=e)}),K.push.apply(s.__h,s._sb),s._sb=[],s.__h.length&&a.push(s);break e}s.componentWillUpdate!=null&&s.componentWillUpdate(h,s.__s,T),v&&s.componentDidUpdate!=null&&s.__h.push(function(){s.componentDidUpdate(_,y,R)})}if(s.context=T,s.props=h,s.__P=t,s.__e=!1,L=x.__r,N=0,v)s.state=s.__s,s.__d=!1,L&&L(e),f=s.render(s.props,s.state,s.context),K.push.apply(s.__h,s._sb),s._sb=[];else do s.__d=!1,L&&L(e),f=s.render(s.props,s.state,s.context),s.state=s.__s;while(s.__d&&++N<25);s.state=s.__s,s.getChildContext!=null&&(o=O(O({},o),s.getChildContext())),v&&!p&&s.getSnapshotBeforeUpdate!=null&&(R=s.getSnapshotBeforeUpdate(_,y)),C=f!=null&&f.type===G&&f.key==null?Oe(f.props.children):f,u=De(t,te(C)?C:[C],e,r,o,i,n,a,u,m,l),s.base=e.__e,e.__u&=-161,s.__h.length&&a.push(s),g&&(s.__E=s.__=null)}catch(b){if(e.__v=null,m||n!=null)if(b.then){for(e.__u|=m?160:128;u&&u.nodeType==8&&u.nextSibling;)u=u.nextSibling;n[n.indexOf(u)]=null,e.__e=u}else{for(I=n.length;I--;)ue(n[I]);le(e)}else e.__e=r.__e,e.__k=r.__k,b.then||le(e);x.__e(b,e,r)}else n==null&&e.__v==r.__v?(e.__k=r.__k,e.__e=r.__e):u=e.__e=it(r.__e,e,r,o,i,n,a,m,l);return(f=x.diffed)&&f(e),128&e.__u?void 0:u}function le(t){t&&(t.__c&&(t.__c.__e=!0),t.__k&&t.__k.some(le))}function Le(t,e,r){for(var o=0;o<r.length;o++)_e(r[o],r[++o],r[++o]);x.__c&&x.__c(e,t),t.some(function(i){try{t=i.__h,i.__h=[],t.some(function(n){n.call(i)})}catch(n){x.__e(n,i.__v)}})}function Oe(t){return typeof t!="object"||t==null||t.__b>0?t:te(t)?t.map(Oe):t.constructor!==void 0?null:O({},t)}function it(t,e,r,o,i,n,a,u,m){var l,f,s,p,_,y,R,g=r.props||J,h=e.props,v=e.type;if(v=="svg"?i="http://www.w3.org/2000/svg":v=="math"?i="http://www.w3.org/1998/Math/MathML":i||(i="http://www.w3.org/1999/xhtml"),n!=null){for(l=0;l<n.length;l++)if((_=n[l])&&"setAttribute"in _==!!v&&(v?_.localName==v:_.nodeType==3)){t=_,n[l]=null;break}}if(t==null){if(v==null)return document.createTextNode(h);t=document.createElementNS(i,v,h.is&&h),u&&(x.__m&&x.__m(e,n),u=!1),n=null}if(v==null)g===h||u&&t.data==h||(t.data=h);else{if(n=v=="textarea"&&h.defaultValue!=null?null:n&&ee.call(t.childNodes),!u&&n!=null)for(g={},l=0;l<t.attributes.length;l++)g[(_=t.attributes[l]).name]=_.value;for(l in g)_=g[l],l=="dangerouslySetInnerHTML"?s=_:l=="children"||l in h||l=="value"&&"defaultValue"in h||l=="checked"&&"defaultChecked"in h||q(t,l,null,_,i);for(l in h)_=h[l],l=="children"?p=_:l=="dangerouslySetInnerHTML"?f=_:l=="value"?y=_:l=="checked"?R=_:u&&typeof _!="function"||g[l]===_||q(t,l,_,g[l],i);if(f)u||s&&(f.__html==s.__html||f.__html==t.innerHTML)||(t.innerHTML=f.__html),e.__k=[];else if(s&&(t.innerHTML=""),De(e.type=="template"?t.content:t,te(p)?p:[p],e,r,o,v=="foreignObject"?"http://www.w3.org/1999/xhtml":i,n,a,n?n[0]:r.__k&&U(r,0),u,m),n!=null)for(l=n.length;l--;)ue(n[l]);u&&v!="textarea"||(l="value",v=="progress"&&y==null?t.removeAttribute("value"):y!=null&&(y!==t[l]||v=="progress"&&!y||v=="option"&&y!=g[l])&&q(t,l,y,g[l],i),l="checked",R!=null&&R!=t[l]&&q(t,l,R,g[l],i))}return t}function _e(t,e,r){try{if(typeof t=="function"){var o=typeof t.__u=="function";o&&t.__u(),o&&e==null||(t.__u=t(e))}else t.current=e}catch(i){x.__e(i,r)}}function Ne(t,e,r){var o,i;if(x.unmount&&x.unmount(t),(o=t.ref)&&(o.current&&o.current!=t.__e||_e(o,null,e)),(o=t.__c)!=null){if(o.componentWillUnmount)try{o.componentWillUnmount()}catch(n){x.__e(n,e)}o.base=o.__P=null}if(o=t.__k)for(i=0;i<o.length;i++)o[i]&&Ne(o[i],e,r||typeof t.type!="function");r||ue(t.__e),t.__c=t.__=t.__e=void 0}function nt(t,e,r){return this.constructor(t,r)}function Ce(t,e,r){var o,i,n,a;e==document&&(e=document.documentElement),x.__&&x.__(t,e),i=(o=typeof r=="function")?null:r&&r.__k||e.__k,n=[],a=[],de(e,t=(!o&&r||e).__k=c(G,null,[t]),i||J,J,e.namespaceURI,!o&&r?[r]:i?null:e.firstChild?ee.call(e.childNodes):null,n,!o&&r?r:i?i.__e:e.firstChild,o,a),Le(n,t,a)}ee=K.slice,x={__e:function(t,e,r,o){for(var i,n,a;e=e.__;)if((i=e.__c)&&!i.__)try{if((n=i.constructor)&&n.getDerivedStateFromError!=null&&(i.setState(n.getDerivedStateFromError(t)),a=i.__d),i.componentDidCatch!=null&&(i.componentDidCatch(t,o||{}),a=i.__d),a)return i.__E=i}catch(u){t=u}throw t}},Re=0,Ke=function(t){return t!=null&&t.constructor===void 0},Y.prototype.setState=function(t,e){var r;r=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=O({},this.state),typeof t=="function"&&(t=t(O({},r),this.props)),t&&O(r,t),t!=null&&this.__v&&(e&&this._sb.push(e),we(this))},Y.prototype.forceUpdate=function(t){this.__v&&(this.__e=!0,t&&this.__h.push(t),we(this))},Y.prototype.render=G,F=[],ke=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,Ee=function(t,e){return t.__v.__b-e.__v.__b},Z.__r=0,ne=Math.random().toString(8),W="__d"+ne,X="__a"+ne,Pe=/(PointerCapture)$|Capture$/i,ce=0,se=Se(!1),ae=Se(!0),Ze=0;var fe={$schema:"https://acode.app/schema/plugin/v0.1.0.json",id:"acode.distro-manager",name:"Distro Manager",main:"main.js",version:"1.0.0",repository:"https://github.com/Acode-Foundation/acode-plugin.git",icon:"icon.png",minVersionCode:290,license:"MIT",keywords:["terminal","linux","distro","ubuntu","debian","arch","devcontainer"],price:0,author:{name:"Acode Foundation",email:"",github:"Acode-Foundation"}};var at={alpine:{name:"Alpine Linux",version:"3.21",description:"Lightweight musl-based distro, fast and minimal",icon:"\u{1F3D4}\uFE0F",pkgManager:"apk",urls:{"arm64-v8a":"https://dl-cdn.alpinelinux.org/alpine/v3.21/releases/aarch64/alpine-minirootfs-3.21.0-aarch64.tar.gz","armeabi-v7a":"https://dl-cdn.alpinelinux.org/alpine/v3.21/releases/armhf/alpine-minirootfs-3.21.0-armhf.tar.gz",x86_64:"https://dl-cdn.alpinelinux.org/alpine/v3.21/releases/x86_64/alpine-minirootfs-3.21.0-x86_64.tar.gz"},size:"~3MB",shell:"/bin/sh",isXz:!1},debian:{name:"Debian",version:"trixie",description:"Stable and reliable, the universal operating system",icon:"\u{1F300}",pkgManager:"apt",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.29.0/debian-trixie-aarch64-pd-v4.29.0.tar.xz","armeabi-v7a":"https://github.com/termux/proot-distro/releases/download/v4.29.0/debian-trixie-arm-pd-v4.29.0.tar.xz",x86_64:"https://github.com/termux/proot-distro/releases/download/v4.29.0/debian-trixie-x86_64-pd-v4.29.0.tar.xz"},size:"~35MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},ubuntu:{name:"Ubuntu",version:"25.10 (Questing)",description:"Popular Debian-based distro with apt package manager",icon:"\u{1F7E0}",pkgManager:"apt",urls:{"arm64-v8a":"https://easycli.sh/proot-distro/ubuntu-questing-aarch64-pd-v4.37.0.tar.xz","armeabi-v7a":"https://easycli.sh/proot-distro/ubuntu-questing-arm-pd-v4.37.0.tar.xz",x86_64:"https://easycli.sh/proot-distro/ubuntu-questing-x86_64-pd-v4.37.0.tar.xz"},size:"~58MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},arch:{name:"Arch Linux",version:"latest",description:"Rolling release with pacman, for power users",icon:"\u{1F535}",pkgManager:"pacman",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.34.2/archlinux-aarch64-pd-v4.34.2.tar.xz","armeabi-v7a":"https://github.com/termux/proot-distro/releases/download/v4.34.2/archlinux-arm-pd-v4.34.2.tar.xz",x86_64:"https://github.com/termux/proot-distro/releases/download/v4.34.2/archlinux-x86_64-pd-v4.34.2.tar.xz"},size:"~160MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},fedora:{name:"Fedora",version:"43",description:"Cutting-edge features with dnf package manager",icon:"\u{1F3A9}",pkgManager:"dnf",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.31.0/fedora-aarch64-pd-v4.31.0.tar.xz",x86_64:"https://github.com/termux/proot-distro/releases/download/v4.31.0/fedora-x86_64-pd-v4.31.0.tar.xz"},size:"~38MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},void:{name:"Void Linux",version:"latest",description:"Independent distro with runit and xbps",icon:"\u26AB",pkgManager:"xbps-install",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.29.0/void-aarch64-pd-v4.29.0.tar.xz","armeabi-v7a":"https://github.com/termux/proot-distro/releases/download/v4.29.0/void-arm-pd-v4.29.0.tar.xz",x86_64:"https://github.com/termux/proot-distro/releases/download/v4.29.0/void-x86_64-pd-v4.29.0.tar.xz"},size:"~51MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},opensuse:{name:"openSUSE",version:"tumbleweed",description:"Rolling release with zypper package manager",icon:"\u{1F98E}",pkgManager:"zypper",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.34.2/opensuse-aarch64-pd-v4.34.2.tar.xz",x86_64:"https://github.com/termux/proot-distro/releases/download/v4.34.2/opensuse-x86_64-pd-v4.34.2.tar.xz"},size:"~44MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},manjaro:{name:"Manjaro",version:"latest",description:"User-friendly Arch-based with pacman",icon:"\u{1F7E2}",pkgManager:"pacman",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.34.2/manjaro-aarch64-pd-v4.34.2.tar.xz"},size:"~141MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0}},D=at;var lt="distros",ct="distro-manager.json";function Ie(t){return`'${String(t).replace(/'/g,"'\\''")}'`}var pe=class{constructor(e){this.filesDir=e,this.distrosPath=`${e}/${lt}`,this.configPath=`${e}/${ct}`,this.arch=null,this.config={installed:{},activeDistro:null}}async init(){this.arch=await new Promise((e,r)=>{system.getArch(e,r)}),await this.ensureDistrosDir(),await this.loadConfig()}async ensureDistrosDir(){await this.fileExists(this.distrosPath)||await new Promise((r,o)=>{system.mkdirs(this.distrosPath,r,o)})}async loadConfig(){try{if(await this.fileExists(this.configPath)){let r=await Executor.BackgroundExecutor.execute(`cat "${this.configPath}"`);this.config=JSON.parse(r)}}catch(e){console.warn("Failed to load config, using defaults:",e)}}async saveConfig(){let e=JSON.stringify(this.config,null,2);await new Promise((r,o)=>{system.writeText(this.configPath,e,r,o)})}fileExists(e){return new Promise((r,o)=>{system.fileExists(e,!1,i=>{r(i===1)},o)})}getAvailableDistros(){return Object.entries(D).filter(([e,r])=>r.urls[this.arch]).map(([e,r])=>({id:e,...r,installed:!!this.config.installed[e],active:this.config.activeDistro===e}))}getDistroInfo(e){let r=D[e];return r?{id:e,...r,installed:!!this.config.installed[e],active:this.config.activeDistro===e,installPath:`${this.distrosPath}/${e}`}:null}async install(e,r=console.log){let o=D[e];if(!o)throw new Error(`Unknown distro: ${e}`);let i=o.urls[this.arch];if(!i)throw new Error(`Distro ${e} not available for ${this.arch}`);let n=`${this.distrosPath}/${e}`,a=`${n}/rootfs`,u=o.isXz||i.endsWith(".xz"),m=`${e}.tar${u?".xz":".gz"}`,l=`${this.filesDir}/${m}`,f=`${this.filesDir}/${e}.tar`;try{if(r(`${o.icon} Installing ${o.name} ${o.version}...`),r(`\u{1F4E6} Size: ${o.size}`),await this.fileExists(n)&&(r("\u{1F9F9} Removing existing installation..."),await Executor.execute(`rm -rf "${n}"`)),await new Promise((s,p)=>{system.mkdirs(a,s,p)}),r("\u2B07\uFE0F Downloading rootfs..."),await new Promise((s,p)=>{cordova.plugin.http.downloadFile(i,{},{},cordova.file.dataDirectory+m,s,_=>{console.error("Download error:",_),p(new Error(`Download failed: ${JSON.stringify(_)}`))})}),r("\u{1F4C2} Extracting rootfs..."),u){r("   \u2192 Installing xz-utils..."),await Executor.execute(`sh -c ${Ie("apk add --quiet xz 2>/dev/null || true")}`,!0),r("   \u2192 Decompressing xz archive (this may take a few minutes)..."),await Executor.execute(`sh -c ${Ie(`rm -f "${f}" && xz -dc "${l}" > "${f}"`)}`,!0);let s=f;if((await Executor.BackgroundExecutor.execute(`test -f "${s}" && echo "yes" || echo "no"`)).trim()!=="yes")throw new Error("Failed to decompress xz archive. The downloaded file may be incomplete or corrupted.");r("   \u2192 Extracting tar archive..."),await Executor.execute(`tar --no-same-owner -xf "${s}" -C "${a}" 2>&1`,!0),await Executor.execute(`rm -f "${s}" "${l}"`,!0);let _=await Executor.BackgroundExecutor.execute(`ls "${a}" 2>/dev/null | wc -l`,!0);if(Number.parseInt(_.trim(),10)===0)throw new Error("Extraction produced no files. The archive may be corrupted or xz decompression failed.")}else r("   \u2192 Extracting gzip archive..."),await Executor.execute(`tar --no-same-owner -xzf "${l}" -C "${a}" 2>&1`,!0),await Executor.execute(`rm -f "${l}"`,!0);if(o.isProotDistro){let p=(await Executor.BackgroundExecutor.execute(`ls "${a}" 2>/dev/null || echo ""`)).trim().split(`
`).filter(Boolean),_=["bin","etc","lib","lib64","usr","var","root","home","tmp","dev","proc","sys","run","opt","srv","mnt","media","sbin","boot"];if(p.length===1&&!_.includes(p[0])){r("\u{1F4C1} Fixing rootfs structure...");let y=p[0];await Executor.execute(`cd "${a}" && mv "${y}"/* . 2>/dev/null; rmdir "${y}" 2>/dev/null || true`)}}return r("\u2699\uFE0F Configuring DNS..."),await new Promise((s,p)=>{system.writeText(`${a}/etc/resolv.conf`,`nameserver 8.8.8.8
nameserver 8.8.4.4`,s,p)}),this.config.installed[e]={installedAt:new Date().toISOString(),version:o.version},await this.saveConfig(),r(`\u2705 ${o.name} installed successfully!`),!0}catch(s){throw r(`\u274C Installation failed: ${s.message||s}`),await Executor.execute(`rm -rf "${n}" 2>/dev/null || true`),await Executor.execute(`rm -f "${l}" "${f}" 2>/dev/null || true`),s}}async uninstall(e,r=console.log){let o=D[e];if(!o)throw new Error(`Unknown distro: ${e}`);let i=`${this.distrosPath}/${e}`;r(`\u{1F5D1}\uFE0F Uninstalling ${o.name}...`),this.config.activeDistro===e&&(this.config.activeDistro=null),await Executor.execute(`rm -rf "${i}"`),delete this.config.installed[e],await this.saveConfig(),r(`\u2705 ${o.name} uninstalled`)}async execInDistro(e,r){let o=D[e];if(!o)throw new Error(`Unknown distro: ${e}`);let i=`${this.distrosPath}/${e}/rootfs`,n=this.generateProotScript(i,r,o.shell);return await Executor.execute(n)}async startShell(e,r){let o=D[e];if(!o)throw new Error(`Unknown distro: ${e}`);if(!this.config.installed[e])throw new Error(`${o.name} is not installed`);let i=`${this.distrosPath}/${e}/rootfs`,n=this.generateProotScript(i,o.shell,o.shell);this.config.activeDistro=e,await this.saveConfig();let a=await Executor.start("sh",r,!1);return await Executor.write(a,`${n}
`),a}generateProotScript(e,r,o="/bin/sh"){return`
export LD_LIBRARY_PATH=$PREFIX
export PROOT_TMP_DIR=$PREFIX/tmp

mkdir -p "$PREFIX/tmp"

if [ -f "$NATIVE_DIR/libproot.so" ]; then
  export PROOT_LOADER="$NATIVE_DIR/libproot.so"
fi
if [ -f "$NATIVE_DIR/libproot32.so" ]; then
  export PROOT_LOADER32="$NATIVE_DIR/libproot32.so"
fi
export PROOT="$NATIVE_DIR/libproot-xed.so"

ARGS="--kill-on-exit"

for mnt in /apex /odm /product /system /system_ext /vendor /linkerconfig/ld.config.txt; do
  [ -e "$mnt" ] && ARGS="$ARGS -b $(realpath $mnt)"
done

ARGS="$ARGS -b /sdcard -b /storage -b /dev -b /data -b /proc -b /sys"
ARGS="$ARGS -b /dev/urandom:/dev/random"
ARGS="$ARGS -b $PREFIX/public:/public"
ARGS="$ARGS -b $PREFIX/public:/home"
ARGS="$ARGS -b $PREFIX/public:/root"
ARGS="$ARGS -r ${e}"
ARGS="$ARGS -0 --link2symlink --sysvipc -L"
ARGS="$ARGS -w /root"

$PROOT $ARGS ${o} -c "${r.replace(/"/g,'\\"')}"
`}async getInstalledSize(e){let r=`${this.distrosPath}/${e}`;try{return(await Executor.BackgroundExecutor.execute(`du -sh "${r}" 2>/dev/null | cut -f1`)).trim()||"Unknown"}catch{return"Unknown"}}},Me=pe;var V,w,me,Fe,oe=0,je=[],$=x,Ge=$.__b,ze=$.__r,He=$.diffed,Ue=$.__c,Be=$.unmount,Xe=$.__;function ge(t,e){$.__h&&$.__h(w,t,oe||e),oe=0;var r=w.__H||(w.__H={__:[],__h:[]});return t>=r.__.length&&r.__.push({}),r.__[t]}function z(t){return oe=1,ut(Qe,t)}function ut(t,e,r){var o=ge(V++,2);if(o.t=t,!o.__c&&(o.__=[r?r(e):Qe(void 0,e),function(u){var m=o.__N?o.__N[0]:o.__[0],l=o.t(m,u);m!==l&&(o.__N=[l,o.__[1]],o.__c.setState({}))}],o.__c=w,!w.__f)){var i=function(u,m,l){if(!o.__c.__H)return!0;var f=o.__c.__H.__.filter(function(p){return p.__c});if(f.every(function(p){return!p.__N}))return!n||n.call(this,u,m,l);var s=o.__c.props!==u;return f.some(function(p){if(p.__N){var _=p.__[0];p.__=p.__N,p.__N=void 0,_!==p.__[0]&&(s=!0)}}),n&&n.call(this,u,m,l)||s};w.__f=!0;var n=w.shouldComponentUpdate,a=w.componentWillUpdate;w.componentWillUpdate=function(u,m,l){if(this.__e){var f=n;n=void 0,i(u,m,l),n=f}a&&a.call(this,u,m,l)},w.shouldComponentUpdate=i}return o.__N||o.__}function ve(t,e){var r=ge(V++,3);!$.__s&&We(r.__H,e)&&(r.__=t,r.u=e,w.__H.__h.push(r))}function qe(t){return oe=5,dt(function(){return{current:t}},[])}function dt(t,e){var r=ge(V++,7);return We(r.__H,e)&&(r.__=t(),r.__H=e,r.__h=t),r.__}function _t(){for(var t;t=je.shift();){var e=t.__H;if(t.__P&&e)try{e.__h.some(re),e.__h.some(he),e.__h=[]}catch(r){e.__h=[],$.__e(r,t.__v)}}}$.__b=function(t){w=null,Ge&&Ge(t)},$.__=function(t,e){t&&e.__k&&e.__k.__m&&(t.__m=e.__k.__m),Xe&&Xe(t,e)},$.__r=function(t){ze&&ze(t),V=0;var e=(w=t.__c).__H;e&&(me===w?(e.__h=[],w.__h=[],e.__.some(function(r){r.__N&&(r.__=r.__N),r.u=r.__N=void 0})):(e.__h.some(re),e.__h.some(he),e.__h=[],V=0)),me=w},$.diffed=function(t){He&&He(t);var e=t.__c;e&&e.__H&&(e.__H.__h.length&&(je.push(e)!==1&&Fe===$.requestAnimationFrame||((Fe=$.requestAnimationFrame)||ft)(_t)),e.__H.__.some(function(r){r.u&&(r.__H=r.u),r.u=void 0})),me=w=null},$.__c=function(t,e){e.some(function(r){try{r.__h.some(re),r.__h=r.__h.filter(function(o){return!o.__||he(o)})}catch(o){e.some(function(i){i.__h&&(i.__h=[])}),e=[],$.__e(o,r.__v)}}),Ue&&Ue(t,e)},$.unmount=function(t){Be&&Be(t);var e,r=t.__c;r&&r.__H&&(r.__H.__.some(function(o){try{re(o)}catch(i){e=i}}),r.__H=void 0,e&&$.__e(e,r.__v))};var Ve=typeof requestAnimationFrame=="function";function ft(t){var e,r=function(){clearTimeout(o),Ve&&cancelAnimationFrame(e),setTimeout(t)},o=setTimeout(r,35);Ve&&(e=requestAnimationFrame(r))}function re(t){var e=w,r=t.__c;typeof r=="function"&&(t.__c=void 0,r()),w=e}function he(t){var e=w;t.__c=t.__(),w=e}function We(t,e){return!t||t.length!==e.length||e.some(function(r,o){return r!==t[o]})}function Qe(t,e){return typeof e=="function"?e(t):e}function be({plugin:t}){let[e,r]=z([]),[o,i]=z(""),[n,a]=z(null),[u,m]=z({}),[l,f]=z({}),[s,p]=z(!1),[_,y]=z(()=>localStorage.getItem("distro-manager-default-terminal")||"builtin"),R=qe({}),g=typeof acode<"u"&&!!acode.require("acodex");ve(()=>{let d=()=>{r(t.manager.getAvailableDistros()),m({...t.installStates})};return t.addListener(d),d(),h(),()=>{t.removeListener(d)}},[t]),ve(()=>{Object.keys(u).forEach(d=>{let b=R.current[d];b&&(b.scrollTop=b.scrollHeight)})},[u]);let h=async()=>{p(!0);let d=t.manager.getAvailableDistros(),b={},S=43130,M=Object.keys(t.manager.getAvailableDistros().reduce((k,P)=>(k[P.id]=P,k),{}));for(let k of d)if(k.installed){let P=M.indexOf(k.id),A=S+(P>=0?P:0);await t.checkServerRunning(A)&&(b[k.id]=A)}f(b),p(!1)},v=()=>{h(),r(t.manager.getAvailableDistros())},E=d=>{a(n===d?null:d)},T=async d=>{a(d),await t.installDistro(d),v()},L=async d=>{let b=e.find(P=>P.id===d);if(!b)return;let S=`Are you sure you want to permanently delete ${b.name}? All packages and files in this distribution will be lost.`;await acode.require("confirm")("Uninstall Distribution",S,!0)&&(a(d),await t.uninstallDistro(d),v())},N=async(d,b)=>{let P=43130+t.manager.getAvailableDistros().map(A=>A.id).indexOf(d);try{(b==="acodex"||b==="builtin")&&(await t.launchTerminal(d,b,P),setTimeout(h,1500))}catch(A){acode.alert("Error",`Failed to launch shell: ${A.message||A}`)}},C=async(d,b)=>{d.stopPropagation();let S=[["builtin","Launch with Built-in Terminal","Use Acode terminal UI directly"],["acodex","Launch with AcodeX Terminal","Connect using AcodeX plugin"]],k=await acode.require("select")(`${b.name} Terminal`,S,{textTransform:!1,default:_});k&&(y(k),localStorage.setItem("distro-manager-default-terminal",k),N(b.id,k))},I=e.filter(d=>d.name.toLowerCase().includes(o.toLowerCase())||d.id.toLowerCase().includes(o.toLowerCase()));return c("div",{className:"distro-sidebar scroll"},c("div",{className:"sidebar-header"},c("div",{className:"sidebar-title-container"},c("h3",null,"Distro Manager"),c("span",{className:"arch-tag"},"Arch: ",t.manager.arch||"loading...")),c("button",{className:"btn-refresh",onClick:v,title:"Refresh statuses",disabled:s,style:s?"animation: rotate 1s linear infinite;":""},c("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round"},c("path",{d:"M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"})))),c("div",{className:"sidebar-search"},c("input",{type:"text",placeholder:"Filter distributions...",value:o,onInput:d=>i(d.target.value)})),c("div",{className:"distro-list"},I.length>0?I.map(d=>{let b=n===d.id,S=u[d.id],M=S&&(S.status==="installing"||S.status==="uninstalling"),k=!!l[d.id],P=d.installed,A="",B="";return M?(A=S.status==="installing"?"Installing...":"Removing...",B="busy"):k?(A=`:${l[d.id]}`,B="active"):P&&(A="\u2713",B="installed"),c("div",{className:`distro-card ${k?"active-distro":""}`,key:d.id},c("div",{className:"distro-card-header",onClick:()=>E(d.id)},c("div",{className:"distro-meta"},c("div",{className:"distro-emoji"},d.icon),c("div",{className:"distro-name-ver"},c("span",{className:"distro-name"},d.name),c("span",{className:"distro-ver"},"v",d.version))),c("div",{style:"display: flex; align-items: center; gap: 8px;"},A&&c("span",{className:`status-badge ${B}`},A),c("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2.5",style:`transition: transform 0.2s; ${b?"transform: rotate(180deg);":""}`},c("path",{d:"M6 9l6 6 6-6"})))),b&&c("div",{className:"distro-card-body"},c("p",{className:"distro-desc"},d.description),c("div",{className:"distro-details-grid"},c("div",{className:"detail-row"},c("span",{className:"detail-label"},"Size"),c("span",{className:"detail-value"},d.size)),c("div",{className:"detail-row"},c("span",{className:"detail-label"},"Package Manager"),c("span",{className:"detail-value"},d.pkgManager)),c("div",{className:"detail-row"},c("span",{className:"detail-label"},"Shell"),c("span",{className:"detail-value"},d.shell)),P&&c("div",{className:"detail-row"},c("span",{className:"detail-label"},"Path"),c("span",{className:"detail-value path-value",title:`${t.manager.distrosPath}/${d.id}`},d.id))),M&&S.logs&&c(G,null,c("div",{className:"console-title"},"Process Logs"),c("div",{className:"console-logs",ref:H=>R.current[d.id]=H},S.logs.map((H,ie)=>c("div",{className:"console-line",key:ie},H)))),S&&S.status==="error"&&c(G,null,c("div",{className:"console-title",style:"color: #f44336;"},"Error Output"),c("div",{className:"console-logs",style:"border-color: rgba(244, 67, 54, 0.3);"},c("div",{className:"console-line error"},S.error),S.logs&&S.logs.slice(-5).map((H,ie)=>c("div",{className:"console-line",key:ie,style:"opacity: 0.7;"},H)))),c("div",{className:"actions-container",style:"margin-top: 10px;"},M?c("button",{className:"btn btn-secondary",disabled:!0},c("svg",{className:"spinner",width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"3",style:"animation: spin 1s linear infinite; margin-right: 4px;"},c("circle",{cx:"12",cy:"12",r:"10","stroke-dasharray":"32","stroke-dashoffset":"10"})),"Working..."):P?c(G,null,g?c("div",{className:"btn-group"},c("button",{className:"btn btn-primary btn-launch-main",onClick:()=>N(d.id,_),title:`Launch shell in ${_==="acodex"?"AcodeX":"Built-in Terminal"}`},c("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2.5","stroke-linecap":"round","stroke-linejoin":"round"},c("polygon",{points:"5 3 19 12 5 21 5 3"})),"Launch (",_==="acodex"?"AcodeX":"Built-in",")"),c("button",{className:"btn btn-primary btn-launch-arrow",onClick:H=>C(H,d),title:"Select terminal type"},c("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"3","stroke-linecap":"round","stroke-linejoin":"round"},c("path",{d:"M6 9l6 6 6-6"})))):c("button",{className:"btn btn-primary",onClick:()=>N(d.id,"builtin"),title:"Launch shell in Built-in Terminal"},c("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2.5","stroke-linecap":"round","stroke-linejoin":"round"},c("polygon",{points:"5 3 19 12 5 21 5 3"})),"Launch"),c("button",{className:"btn btn-secondary btn-icon-only",onClick:()=>t.showLaunchLog(d.id),title:"View last launch log"},c("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round"},c("path",{d:"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"}),c("polyline",{points:"14 2 14 8 20 8"}),c("line",{x1:"16",y1:"13",x2:"8",y2:"13"}),c("line",{x1:"16",y1:"17",x2:"8",y2:"17"}),c("polyline",{points:"10 9 9 9 8 9"}))),c("button",{className:"btn btn-danger btn-icon-only",onClick:()=>L(d.id),title:"Uninstall distribution"},c("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round"},c("polyline",{points:"3 6 5 6 21 6"}),c("path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"}),c("line",{x1:"10",y1:"11",x2:"10",y2:"17"}),c("line",{x1:"14",y1:"11",x2:"14",y2:"17"})))):c("button",{className:"btn btn-primary",onClick:()=>T(d.id)},c("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":"2.5","stroke-linecap":"round","stroke-linejoin":"round"},c("path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"}),c("polyline",{points:"7 10 12 15 17 10"}),c("line",{x1:"12",y1:"15",x2:"12",y2:"3"})),"Install"))))}):c("div",{className:"no-results"},"No distributions found.")),c("style",null,`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        @keyframes rotate {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `))}var Ye=`.distro-sidebar.scroll {
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  max-height: 100%;
  padding: 12px;
  overflow-y: auto;
  font-family: inherit;
  color: var(--primary-text-color, #e0e0e0);
  background-color: var(--primary-color, #1a1a1a);
}

/* Custom Scrollbar for modern feel */
.distro-sidebar.scroll::-webkit-scrollbar {
  width: 4px;
}
.distro-sidebar.scroll::-webkit-scrollbar-track {
  background: transparent;
}
.distro-sidebar.scroll::-webkit-scrollbar-thumb {
  background: var(--scrollbar-color, rgba(122, 122, 122, 0.25));
  border-radius: 4px;
}
.distro-sidebar.scroll::-webkit-scrollbar-thumb:hover {
  background: var(--active-color, rgba(122, 122, 122, 0.45));
}

.sidebar-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.sidebar-title-container {
  display: flex;
  flex-direction: column;
}

.sidebar-title-container h3 {
  margin: 0;
  font-size: 1.25em;
  font-weight: 600;
  color: var(--primary-text-color, #ffffff);
}

.sidebar-title-container .arch-tag {
  font-size: 0.75em;
  color: var(--primary-text-color, #888888);
  opacity: 0.7;
  margin-top: 2px;
}

.btn-refresh {
  background: none;
  border: none;
  cursor: pointer;
  padding: 6px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--primary-text-color, #ffffff);
  transition: background-color 0.2s, transform 0.2s;
}

.btn-refresh:hover {
  background-color: rgba(122, 122, 122, 0.15);
}

.btn-refresh:active {
  transform: rotate(45deg);
}

.sidebar-search {
  margin-bottom: 16px;
  width: 100%;
}

.sidebar-search input {
  box-sizing: border-box;
  width: 100%;
  padding: 8px 12px;
  border-radius: 6px;
  border: 1px solid var(--border-color, rgba(122, 122, 122, 0.25));
  background-color: rgba(122, 122, 122, 0.12);
  color: var(--primary-text-color, #ffffff);
  font-size: 0.9em;
  outline: none;
  transition: border-color 0.2s, background-color 0.2s;
}

.sidebar-search input:focus {
  border-color: var(--active-color, #3399ff);
  background-color: rgba(0, 0, 0, 0.15);
}

.distro-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.distro-card {
  border: 1px solid var(--border-color, rgba(122, 122, 122, 0.2));
  border-radius: 8px;
  background-color: var(--secondary-color, #202020);
  overflow: hidden;
  transition: border-color 0.2s, box-shadow 0.2s;
}

.distro-card:hover {
  border-color: var(--border-color, rgba(122, 122, 122, 0.35));
}

.distro-card.active-distro {
  border-color: var(--active-color, #3399ff);
}

.distro-card-header {
  display: flex;
  align-items: center;
  padding: 10px 12px;
  cursor: pointer;
  user-select: none;
  justify-content: space-between;
  gap: 8px;
}

.distro-meta {
  display: flex;
  align-items: center;
  gap: 10px;
  flex: 1;
  min-width: 0;
}

.distro-emoji {
  font-size: 1.5em;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background-color: rgba(122, 122, 122, 0.12);
  flex-shrink: 0;
}

.distro-name-ver {
  display: flex;
  flex-direction: column;
  min-width: 0;
  flex: 1;
}

.distro-name {
  font-weight: 600;
  font-size: 0.95em;
  white-space: normal;
  word-wrap: break-word;
  line-height: 1.25;
  color: var(--secondary-text-color, #ffffff);
}

.distro-ver {
  font-size: 0.75em;
  color: var(--secondary-text-color, #888888);
  opacity: 0.75;
  margin-top: 2px;
}

.status-badge {
  font-size: 0.75em;
  padding: 2px 6px;
  border-radius: 10px;
  font-weight: bold;
  text-transform: uppercase;
  flex-shrink: 0;
}

.status-badge.installed {
  background-color: transparent;
  color: var(--success-text-color, #4CAF50);
  font-size: 0.95em;
  padding: 0 4px;
}

.status-badge.active {
  background-color: rgba(76, 175, 80, 0.12);
  color: var(--success-text-color, #4CAF50);
  border: 1px solid var(--success-text-color, rgba(76, 175, 80, 0.3));
  font-size: 0.72em;
  padding: 1px 5px;
}

.status-badge.busy {
  background-color: rgba(255, 152, 0, 0.15);
  color: #FF9800;
  animation: pulse 1.5s infinite;
}

@keyframes pulse {
  0% { opacity: 0.6; }
  50% { opacity: 1; }
  100% { opacity: 0.6; }
}

.distro-card-body {
  padding: 0 12px 12px 12px;
  border-top: 1px dashed var(--border-color, rgba(122, 122, 122, 0.15));
  margin-top: 2px;
  animation: slideDown 0.2s ease-out;
}

@keyframes slideDown {
  from { opacity: 0; transform: translateY(-5px); }
  to { opacity: 1; transform: translateY(0); }
}

.distro-desc {
  font-size: 0.8em;
  color: var(--secondary-text-color, #aaaaaa);
  opacity: 0.85;
  margin: 10px 0;
  line-height: 1.4;
}

.distro-details-grid {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
  background-color: rgba(0, 0, 0, 0.12);
  padding: 8px;
  border-radius: 6px;
}

.detail-row {
  display: flex;
  justify-content: space-between;
  font-size: 0.78em;
}

.detail-label {
  color: var(--secondary-text-color, #777777);
  opacity: 0.65;
}

.detail-value {
  font-weight: 500;
  color: var(--secondary-text-color, #ffffff);
}

.detail-value.path-value {
  max-width: 140px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.actions-container {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 12px;
  font-size: 0.8em;
  font-weight: 600;
  border-radius: 6px;
  border: none;
  cursor: pointer;
  transition: opacity 0.2s, background-color 0.2s;
  flex: 1;
  min-width: 0;
}

.btn:hover {
  opacity: 0.9;
}

.btn:active {
  transform: scale(0.98);
}

.btn-primary {
  background-color: var(--button-background-color, #3399ff);
  color: var(--button-text-color, #ffffff);
}

.btn-primary:active {
  background-color: var(--button-active-color, #2c8ef0);
}

.btn-secondary {
  background-color: rgba(122, 122, 122, 0.18);
  color: var(--secondary-text-color, #ffffff);
}

.btn-danger {
  background-color: var(--danger-color, #a03300);
  color: var(--danger-text-color, #ffffff);
}

.btn-icon-only {
  flex: 0 0 auto;
  width: 32px;
  padding: 0;
}

/* Split Button layout */
.btn-group {
  display: inline-flex;
  flex: 2;
  min-width: 0;
  border-radius: 6px;
  overflow: hidden;
}

.btn-group .btn-launch-main {
  flex: 1;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}

.btn-group .btn-launch-arrow {
  flex: 0 0 auto;
  width: 30px;
  padding: 0;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
  border-left: 1px solid var(--border-color, rgba(255, 255, 255, 0.15));
}

/* Console logs styling inside card */
.console-logs {
  background-color: rgba(0, 0, 0, 0.35);
  border: 1px solid var(--border-color, rgba(122, 122, 122, 0.2));
  border-radius: 6px;
  padding: 8px;
  margin-top: 10px;
  font-family: 'Courier New', Courier, monospace;
  font-size: 0.72em;
  color: var(--success-text-color, #4af626);
  max-height: 120px;
  overflow-y: auto;
}

.console-line {
  white-space: pre-wrap;
  word-wrap: break-word;
  margin-bottom: 4px;
}

.console-line.error {
  color: var(--danger-color, #f44336);
}

.console-title {
  font-size: 0.75em;
  color: var(--secondary-text-color, #888888);
  opacity: 0.75;
  margin-top: 10px;
  margin-bottom: 4px;
  font-weight: bold;
  text-transform: uppercase;
}

.no-results {
  text-align: center;
  padding: 30px 10px;
  color: var(--primary-text-color, #888888);
  opacity: 0.7;
  font-size: 0.9em;
}
`;var Ot=acode.require("confirm"),j=acode.require("alert"),Nt=acode.require("select"),Ct=acode.require("loader");var Je=8;function mt(t){return`'${String(t).replace(/'/g,"'\\''")}'`}var xe=class{constructor(){this.manager=null,this.baseUrl="",this.filesDir="",this.listeners=[],this.installStates={},this.sidebarId="distro-manager",this.$style=null}async init(){this.filesDir=await new Promise((e,r)=>{system.getFilesDir(e,r)}),this.manager=new Me(this.filesDir),await this.manager.init(),this.initSidebar()}initSidebar(){let e=acode.require("sidebarApps");if(!e){console.warn("[DistroManager] sidebarApps API not available");return}acode.addIcon("distro-manager-icon",`${this.baseUrl}icon.png`),this.$style=document.createElement("style"),this.$style.innerHTML=Ye,document.head.appendChild(this.$style),e.add("distro-manager-icon",this.sidebarId,"Distro Manager",r=>{r.classList.add("scroll"),r.style.maxHeight="100%",r.style.overflowY="auto",Ce(c(be,{plugin:this}),r)},!1,()=>{this.notifyListeners()})}addListener(e){this.listeners.push(e)}removeListener(e){this.listeners=this.listeners.filter(r=>r!==e)}notifyListeners(){this.listeners.forEach(e=>{try{e()}catch(r){console.error("[DistroManager] Listener notify error:",r)}})}async installDistro(e){let r=D[e];if(!r)return;this.installStates[e]={status:"installing",logs:[`\u{1F3D4}\uFE0F Initializing ${r.name} installation...`]},this.notifyListeners();let o=i=>{this.installStates[e]&&(this.installStates[e].logs.push(i),this.installStates[e].logs.length>50&&this.installStates[e].logs.shift(),this.notifyListeners()),console.log(`[DistroManager] ${i}`)};try{await this.manager.install(e,o),await this.createDistroInitScript(e,{force:!0}),this.installStates[e]={status:"success",logs:[...this.installStates[e].logs,"\u2713 Installed successfully!"]},this.notifyListeners(),setTimeout(()=>{delete this.installStates[e],this.notifyListeners()},3e3)}catch(i){console.error("[DistroManager] Installation failed:",i),this.installStates[e]={status:"error",error:i.message||String(i),logs:this.installStates[e]?this.installStates[e].logs:[]},this.notifyListeners()}}async uninstallDistro(e){let r=D[e];if(!r)return;this.installStates[e]={status:"uninstalling",logs:[`\u{1F5D1}\uFE0F Preparing to remove ${r.name}...`]},this.notifyListeners();let o=i=>{this.installStates[e]&&(this.installStates[e].logs.push(i),this.notifyListeners()),console.log(`[DistroManager] ${i}`)};try{await this.manager.uninstall(e,o),this.installStates[e]={status:"success",logs:[...this.installStates[e].logs,"\u2713 Removed successfully!"]},this.notifyListeners(),setTimeout(()=>{delete this.installStates[e],this.notifyListeners()},3e3)}catch(i){console.error("[DistroManager] Uninstallation failed:",i),this.installStates[e]={status:"error",error:i.message||String(i),logs:this.installStates[e]?this.installStates[e].logs:[]},this.notifyListeners()}}async ensureDistroInitScript(e){let r=this.manager.config.installed[e],o=`${this.manager.distrosPath}/${e}/init-distro.sh`,n=`${`${this.manager.distrosPath}/${e}/rootfs`}/etc/acode-initrc`;return r?.initScriptVersion===Je&&await this.manager.fileExists(o)&&await this.manager.fileExists(n)?o:this.createDistroInitScript(e,{force:!0})}async createDistroInitScript(e,{force:r=!1}={}){let o=D[e],i=`${this.manager.distrosPath}/${e}/rootfs`,n=`${this.manager.distrosPath}/${e}`,a=`${this.manager.distrosPath}/${e}/init-distro.sh`,u=`${i}/etc/acode-initrc`,m=`${n}/last-launch.log`;if(!r&&await this.manager.fileExists(a))return a;let l=o.name.toLowerCase().replace(/\s+/g,""),f=`# Acode ${o.name} Shell Configuration
export HOME=/root
export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:/system/bin
export TERM=xterm-256color
export LANG=C.UTF-8
export SHELL=${o.shell}

# Source system profiles if they exist
[ -f /etc/profile ] && . /etc/profile
[ -f /etc/bash.bashrc ] && . /etc/bash.bashrc
[ -f ~/.bashrc ] && . ~/.bashrc

# Unset PROMPT_COMMAND to prevent it overriding our prompt
unset PROMPT_COMMAND

# Color prompt: user@distro:path$
if [ -n "$BASH_VERSION" ]; then
  PS1='\\[\\033[1;32m\\]\\u\\[\\033[0m\\]@\\[\\033[1;35m\\]${l}\\[\\033[0m\\]:\\[\\033[1;34m\\]\\w\\[\\033[0m\\]\\$ '
else
  # POSIX sh
  PS1='\\033[1;32m$(whoami 2>/dev/null || echo root)\\033[0m@\\033[1;35m${l}\\033[0m:\\033[1;34m$PWD\\033[0m# '
fi

# Show welcome message
if [ -z "$ACODE_MOTD_SHOWN" ]; then
  export ACODE_MOTD_SHOWN=1
  printf "\\033[1;35m  \u{1F680} ${o.name} environment loaded successfully.\\033[0m\\n"
  printf "\\033[1;30m  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\\033[0m\\n"
  printf "   \\033[1;32m\u2022 Package Manager :\\033[0m \\033[1;36m${o.pkgManager}\\033[0m\\n"
  printf "   \\033[1;32m\u2022 Home Directory  :\\033[0m \\033[1;36m\\$HOME\\033[0m\\n"
  printf "   \\033[1;32m\u2022 Quick Editor    :\\033[0m Run \\033[1;33macode <file>\\033[0m to edit\\n"
  printf "\\033[1;30m  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\\033[0m\\n\\n"
fi

cd "$HOME" 2>/dev/null || cd /root 2>/dev/null || cd /
`,s=`${i}/etc/profile`;try{let g="";await this.manager.fileExists(s)&&(g=await Executor.BackgroundExecutor.execute(`cat "${s}"`));let v="# >>> Acode Distro Init Start >>>",E="# <<< Acode Distro Init End <<<",T=g.indexOf(v),L=g.indexOf(E);T!==-1&&L!==-1&&(g=g.slice(0,T)+g.slice(L+E.length));let N=`
${v}
# Acode ${o.name} Shell Configuration
export HOME=/root
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/system/bin
export TERM=xterm-256color
export LANG=C.UTF-8
export SHELL=${o.shell}

# Unset PROMPT_COMMAND to prevent it overriding our prompt
unset PROMPT_COMMAND

if [ -n "$BASH_VERSION" ]; then
  PS1='\\[\\033[1;32m\\]\\u\\[\\033[0m\\]@\\[\\033[1;35m\\]${l}\\[\\033[0m\\]:\\[\\033[1;34m\\]\\w\\[\\033[0m\\]\\$ '
else
  PS1='\\033[1;32m$(whoami 2>/dev/null || echo root)\\033[0m@\\033[1;35m${l}\\033[0m:\\033[1;34m$PWD\\033[0m# '
fi

if [ -z "$ACODE_MOTD_SHOWN" ]; then
  export ACODE_MOTD_SHOWN=1
  printf "\\033[1;35m  \u{1F680} ${o.name} environment loaded successfully.\\033[0m\\n"
  printf "\\033[1;30m  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\\033[0m\\n"
  printf "   \\033[1;32m\u2022 Package Manager :\\033[0m \\033[1;36m${o.pkgManager}\\033[0m\\n"
  printf "   \\033[1;32m\u2022 Home Directory  :\\033[0m \\033[1;36m\\$HOME\\033[0m\\n"
  printf "   \\033[1;32m\u2022 Quick Editor    :\\033[0m Run \\033[1;33macode <file>\\033[0m to edit\\n"
  printf "\\033[1;30m  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\\033[0m\\n\\n"
fi

cd "\\$HOME" 2>/dev/null || cd /root 2>/dev/null || cd /
${E}
`;g=g.trim()+`
`+N,await new Promise((C,I)=>{system.writeText(s,g,C,I)})}catch(g){console.warn("[DistroManager] Failed to update /etc/profile:",g)}let p=`#!/bin/sh
export LD_LIBRARY_PATH=$PREFIX
export PROOT_TMP_DIR=$PREFIX/tmp
export ENV=/etc/acode-initrc
LOG_FILE="${m}"

log() {
  printf '%s %s\\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG_FILE"
}

: > "$LOG_FILE"
log "starting ${o.name} launcher"
log "PREFIX=$PREFIX"
log "NATIVE_DIR=$NATIVE_DIR"
log "FDROID=$FDROID"

mkdir -p "$PREFIX/tmp"
mkdir -p "$PREFIX/public"
mkdir -p "${i}/tmp"

if [ -f "$NATIVE_DIR/libproot.so" ]; then
  export PROOT_LOADER="$NATIVE_DIR/libproot.so"
fi
if [ -f "$NATIVE_DIR/libproot32.so" ]; then
  export PROOT_LOADER32="$NATIVE_DIR/libproot32.so"
fi

if [ "$FDROID" = "true" ]; then
  export PROOT="$PREFIX/libproot-xed.so"
  chmod +x $PREFIX/*
else
  if [ -e "$PREFIX/libtalloc.so.2" ] || [ -L "$PREFIX/libtalloc.so.2" ]; then
    rm -f "$PREFIX/libtalloc.so.2"
  fi
  ln -sf "$NATIVE_DIR/libtalloc.so" "$PREFIX/libtalloc.so.2"
  export PROOT="$NATIVE_DIR/libproot-xed.so"
fi

log "PROOT=$PROOT"
log "PROOT_LOADER=$PROOT_LOADER"
log "PROOT_LOADER32=$PROOT_LOADER32"

ARGS="--kill-on-exit"

for mnt in /apex /odm /product /system /system_ext /vendor /linkerconfig/ld.config.txt /linkerconfig/com.android.art/ld.config.txt /plat_property_contexts /property_contexts; do
  [ -e "$mnt" ] && ARGS="$ARGS -b $(realpath $mnt)"
done

ARGS="$ARGS -b /sdcard"
ARGS="$ARGS -b /storage"
ARGS="$ARGS -b /dev"
ARGS="$ARGS -b /data"
ARGS="$ARGS -b /dev/urandom:/dev/random"
ARGS="$ARGS -b /proc"
ARGS="$ARGS -b /sys"
ARGS="$ARGS -b $PREFIX"
ARGS="$ARGS -b $PREFIX/public:/public"
ARGS="$ARGS -b $PREFIX/public:/home"
ARGS="$ARGS -b $PREFIX/public:/root"
ARGS="$ARGS -b ${i}/tmp:/dev/shm"

[ -e "/proc/self/fd" ] && ARGS="$ARGS -b /proc/self/fd:/dev/fd"
[ -e "/proc/self/fd/0" ] && ARGS="$ARGS -b /proc/self/fd/0:/dev/stdin"
[ -e "/proc/self/fd/1" ] && ARGS="$ARGS -b /proc/self/fd/1:/dev/stdout"
[ -e "/proc/self/fd/2" ] && ARGS="$ARGS -b /proc/self/fd/2:/dev/stderr"

ARGS="$ARGS -r ${i}"
ARGS="$ARGS -0"
ARGS="$ARGS --link2symlink"
ARGS="$ARGS --sysvipc"
ARGS="$ARGS -L"
ARGS="$ARGS -w /root"

DISTRO_SHELL="${o.shell}"
SHELL_ARGS="-l"

if [ ! -e "${i}$DISTRO_SHELL" ]; then
  if [ -e "${i}/bin/bash" ]; then
    DISTRO_SHELL="/bin/bash"
  elif [ -e "${i}/usr/bin/bash" ]; then
    DISTRO_SHELL="/usr/bin/bash"
  elif [ -e "${i}/bin/sh" ]; then
    DISTRO_SHELL="/bin/sh"
  elif [ -e "${i}/usr/bin/sh" ]; then
    DISTRO_SHELL="/usr/bin/sh"
  fi
fi

case "$DISTRO_SHELL" in
  */bash)
    SHELL_ARGS="--rcfile /etc/acode-initrc -i"
    ;;
esac

if [ ! -x "$PROOT" ]; then
  echo "proot executable is missing or not executable: $PROOT" >&2
  exit 126
fi

if [ ! -e "${i}$DISTRO_SHELL" ]; then
  echo "shell not found in rootfs: $DISTRO_SHELL" >&2
  log "shell not found in rootfs: $DISTRO_SHELL"
  exit 127
fi

log "DISTRO_SHELL=$DISTRO_SHELL"
log "SHELL_ARGS=$SHELL_ARGS"
log "ARGS=$ARGS"
log "executing proot"

exec $PROOT $ARGS "$DISTRO_SHELL" $SHELL_ARGS
`;await new Promise((g,h)=>{system.writeText(u,f,g,h)}),await new Promise((g,h)=>{system.writeText(a,p,g,h)});let _=`${i}/usr/local/bin`;await this.manager.fileExists(_)||await new Promise((g,h)=>{system.mkdirs(_,g,h)});let R=`#!/bin/sh
# acode - Open files/folders in Acode editor from inside distro
if [ $# -eq 0 ]; then
  printf '\\e]7777;open;folder;.\\a'
  exit 0
fi
for arg in "$@"; do
  if [ -d "$arg" ]; then
    printf '\\e]7777;open;folder;%s\\a' "$(realpath "$arg")"
  else
    printf '\\e]7777;open;file;%s\\a' "$(realpath "$arg")"
  fi
done
`;return await new Promise((g,h)=>{system.writeText(`${_}/acode`,R,g,h)}),await new Promise((g,h)=>{system.setExec(`${_}/acode`,!0,g,h)}),await new Promise((g,h)=>{system.setExec(a,!0,g,h)}),this.manager.config.installed[e]&&(this.manager.config.installed[e].initScriptVersion=Je,await this.manager.saveConfig()),a}async launchTerminal(e,r,o){let i=D[e];if(i)try{if(await this.ensureDistroInitScript(e),!await this.checkServerRunning(o)&&!await this.startDistroServerBackground(e,o))throw new Error("PTY server failed to launch");if(r==="acodex"){let a=acode.require("acodex");if(!a){j("AcodeX Not Found","Please install AcodeX from the plugin store to use this terminal.");return}a.isTerminalOpened()&&(a.closeTerminal(),await new Promise(u=>setTimeout(u,300))),await a.openTerminal(270,o)}else if(r==="builtin"){let a=acode.require("terminal");if(!a){j("Built-in Terminal Error","Built-in terminal is not available in your Acode version.");return}let u=await this.createDistroSession(o);await a.create({name:`${i.icon} ${i.name}`,port:o,pid:u}),this.manager.config.activeDistro=e,await this.manager.saveConfig()}}catch(n){console.error("[DistroManager] Failed to launch terminal:",n),j("Error",`Failed to start shell: ${n.message||n}`)}}async startDistroServerBackground(e,r){let o=await this.ensureDistroInitScript(e),i=`${this.filesDir}/axs`;if(!await this.manager.fileExists(i))return j("AXS Not Found",`
				<div style="text-align: left;">
					<p>\u26A0\uFE0F <strong>AXS Server Not Found</strong></p>
					<br>
					<p style="color: #888;">
						The PTY server binary is not installed.<br><br>
						Please open Acode's built-in terminal first to install the required components.
					</p>
				</div>
			`),!1;await new Promise((l,f)=>{system.setExec(i,!0,l,f)}),await new Promise((l,f)=>{system.setExec(o,!0,l,f)});let a=await Executor.start("sh",(l,f)=>{console.log(`[DistroManager AXS] ${l}: ${f}`)}),m=`
chmod +x "$PREFIX/axs" ${mt(o)}
LINKER="/system/bin/linker64"
ARCH="$(uname -m)"
if [ "$ARCH" != "aarch64" ] && [ "$ARCH" != "x86_64" ]; then
  LINKER="/system/bin/linker"
fi
exec "$LINKER" "$PREFIX/axs" -p ${r} -c "sh ${o}"
`;await Executor.write(a,`${m}
`);for(let l=0;l<6;l++)if(await new Promise(s=>setTimeout(s,500)),await this.checkServerRunning(r))return this.manager.config.activeDistro=e,await this.manager.saveConfig(),!0;return console.warn("[DistroManager] Server failed to start in time"),!1}async showLaunchLog(e){let r=D[e],o=`${this.manager.distrosPath}/${e}/last-launch.log`,i="";try{i=await this.manager.fileExists(o)?await Executor.BackgroundExecutor.execute(`cat "${o}"`):"No launch log has been written yet."}catch(a){i=`Failed to read launch log: ${a.message||a}`}let n=String(i).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");j(`${r.icon} ${r.name} Launch Log`,`<pre style="text-align:left; white-space:pre-wrap; font-size:0.8em; max-height:60vh; overflow:auto;">${n}</pre>`)}async createDistroSession(e){let r=await new Promise((o,i)=>{cordova.plugin.http.sendRequest(`http://localhost:${e}/terminals`,{method:"POST",responseType:"text",serializer:"json",data:{cols:80,rows:24}},o,n=>i(new Error(n.error||"Failed to create session")))});if(r.status<200||r.status>=300)throw new Error(`Failed to create session: HTTP ${r.status}`);return r.data.trim()}async checkServerRunning(e){try{return(await fetch(`http://localhost:${e}/`,{method:"GET",signal:AbortSignal.timeout(1e3)})).ok}catch{return!1}}destroy(){let e=acode.require("sidebarApps");e&&this.sidebarId&&e.remove(this.sidebarId),this.$style&&this.$style.remove()}};if(window.acode){let t=new xe;acode.setPluginInit(fe.id,async e=>{e.endsWith("/")||(e+="/"),t.baseUrl=e,await t.init()}),acode.setPluginUnmount(fe.id,()=>{t.destroy()})}})();
