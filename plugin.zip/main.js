"use strict";(()=>{var $={$schema:"https://acode.app/schema/plugin/v0.1.0.json",id:"acode.distro-manager",name:"Distro Manager",main:"main.js",version:"1.0.0",repository:"https://github.com/Acode-Foundation/acode-plugin.git",icon:"icon.png",minVersionCode:290,license:"MIT",keywords:["terminal","linux","distro","ubuntu","debian","arch","devcontainer"],price:0,author:{name:"Acode Foundation",email:"",github:"Acode-Foundation"}};var A={alpine:{name:"Alpine Linux",version:"3.21",description:"Lightweight musl-based distro, fast and minimal",icon:"\u{1F3D4}\uFE0F",pkgManager:"apk",urls:{"arm64-v8a":"https://dl-cdn.alpinelinux.org/alpine/v3.21/releases/aarch64/alpine-minirootfs-3.21.0-aarch64.tar.gz","armeabi-v7a":"https://dl-cdn.alpinelinux.org/alpine/v3.21/releases/armhf/alpine-minirootfs-3.21.0-armhf.tar.gz",x86_64:"https://dl-cdn.alpinelinux.org/alpine/v3.21/releases/x86_64/alpine-minirootfs-3.21.0-x86_64.tar.gz"},size:"~3MB",shell:"/bin/sh",isXz:!1},debian:{name:"Debian",version:"trixie",description:"Stable and reliable, the universal operating system",icon:"\u{1F300}",pkgManager:"apt",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.29.0/debian-trixie-aarch64-pd-v4.29.0.tar.xz","armeabi-v7a":"https://github.com/termux/proot-distro/releases/download/v4.29.0/debian-trixie-arm-pd-v4.29.0.tar.xz",x86_64:"https://github.com/termux/proot-distro/releases/download/v4.29.0/debian-trixie-x86_64-pd-v4.29.0.tar.xz"},size:"~35MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},ubuntu:{name:"Ubuntu",version:"25.10 (Questing)",description:"Popular Debian-based distro with apt package manager",icon:"\u{1F7E0}",pkgManager:"apt",urls:{"arm64-v8a":"https://easycli.sh/proot-distro/ubuntu-questing-aarch64-pd-v4.37.0.tar.xz","armeabi-v7a":"https://easycli.sh/proot-distro/ubuntu-questing-arm-pd-v4.37.0.tar.xz",x86_64:"https://easycli.sh/proot-distro/ubuntu-questing-x86_64-pd-v4.37.0.tar.xz"},size:"~58MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},arch:{name:"Arch Linux",version:"latest",description:"Rolling release with pacman, for power users",icon:"\u{1F535}",pkgManager:"pacman",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.34.2/archlinux-aarch64-pd-v4.34.2.tar.xz","armeabi-v7a":"https://github.com/termux/proot-distro/releases/download/v4.34.2/archlinux-arm-pd-v4.34.2.tar.xz",x86_64:"https://github.com/termux/proot-distro/releases/download/v4.34.2/archlinux-x86_64-pd-v4.34.2.tar.xz"},size:"~160MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},fedora:{name:"Fedora",version:"43",description:"Cutting-edge features with dnf package manager",icon:"\u{1F3A9}",pkgManager:"dnf",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.31.0/fedora-aarch64-pd-v4.31.0.tar.xz",x86_64:"https://github.com/termux/proot-distro/releases/download/v4.31.0/fedora-x86_64-pd-v4.31.0.tar.xz"},size:"~38MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},void:{name:"Void Linux",version:"latest",description:"Independent distro with runit and xbps",icon:"\u26AB",pkgManager:"xbps-install",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.29.0/void-aarch64-pd-v4.29.0.tar.xz","armeabi-v7a":"https://github.com/termux/proot-distro/releases/download/v4.29.0/void-arm-pd-v4.29.0.tar.xz",x86_64:"https://github.com/termux/proot-distro/releases/download/v4.29.0/void-x86_64-pd-v4.29.0.tar.xz"},size:"~51MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},opensuse:{name:"openSUSE",version:"tumbleweed",description:"Rolling release with zypper package manager",icon:"\u{1F98E}",pkgManager:"zypper",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.34.2/opensuse-aarch64-pd-v4.34.2.tar.xz",x86_64:"https://github.com/termux/proot-distro/releases/download/v4.34.2/opensuse-x86_64-pd-v4.34.2.tar.xz"},size:"~44MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0},manjaro:{name:"Manjaro",version:"latest",description:"User-friendly Arch-based with pacman",icon:"\u{1F7E2}",pkgManager:"pacman",urls:{"arm64-v8a":"https://github.com/termux/proot-distro/releases/download/v4.34.2/manjaro-aarch64-pd-v4.34.2.tar.xz"},size:"~141MB",shell:"/bin/bash",isXz:!0,isProotDistro:!0}},d=A;var P="distros",T="distro-manager.json";function b(p){return`'${String(p).replace(/'/g,"'\\''")}'`}var x=class{constructor(t){this.filesDir=t,this.distrosPath=`${t}/${P}`,this.configPath=`${t}/${T}`,this.arch=null,this.config={installed:{},activeDistro:null}}async init(){this.arch=await new Promise((t,e)=>{system.getArch(t,e)}),await this.ensureDistrosDir(),await this.loadConfig()}async ensureDistrosDir(){await this.fileExists(this.distrosPath)||await new Promise((e,s)=>{system.mkdirs(this.distrosPath,e,s)})}async loadConfig(){try{if(await this.fileExists(this.configPath)){let e=await Executor.BackgroundExecutor.execute(`cat "${this.configPath}"`);this.config=JSON.parse(e)}}catch(t){console.warn("Failed to load config, using defaults:",t)}}async saveConfig(){let t=JSON.stringify(this.config,null,2);system.writeText(this.configPath,t)}fileExists(t){return new Promise((e,s)=>{system.fileExists(t,!1,i=>{e(i===1)},s)})}getAvailableDistros(){return Object.entries(d).filter(([t,e])=>e.urls[this.arch]).map(([t,e])=>({id:t,...e,installed:!!this.config.installed[t],active:this.config.activeDistro===t}))}getDistroInfo(t){let e=d[t];return e?{id:t,...e,installed:!!this.config.installed[t],active:this.config.activeDistro===t,installPath:`${this.distrosPath}/${t}`}:null}async install(t,e=console.log){let s=d[t];if(!s)throw new Error(`Unknown distro: ${t}`);let i=s.urls[this.arch];if(!i)throw new Error(`Distro ${t} not available for ${this.arch}`);let r=`${this.distrosPath}/${t}`,n=`${r}/rootfs`,l=s.isXz||i.endsWith(".xz"),o=`${t}.tar${l?".xz":".gz"}`;try{if(e(`${s.icon} Installing ${s.name} ${s.version}...`),e(`\u{1F4E6} Size: ${s.size}`),await this.fileExists(r)&&(e("\u{1F9F9} Removing existing installation..."),await Executor.execute(`rm -rf "${r}"`)),await new Promise((a,m)=>{system.mkdirs(n,a,m)}),e("\u2B07\uFE0F Downloading rootfs..."),await new Promise((a,m)=>{cordova.plugin.http.downloadFile(i,{},{},cordova.file.dataDirectory+o,a,c=>{console.error("Download error:",c),m(new Error(`Download failed: ${JSON.stringify(c)}`))})}),e("\u{1F4C2} Extracting rootfs..."),l){e("   \u2192 Installing xz-utils..."),await Executor.execute(`sh -c ${b("apk add --quiet xz 2>/dev/null || true")}`,!0),e("   \u2192 Decompressing xz archive (this may take a few minutes)..."),await Executor.execute(`sh -c ${b(`rm -f "$PREFIX/${t}.tar" && xz -dc "$PREFIX/${o}" > "$PREFIX/${t}.tar"`)}`,!0);let a=`$PREFIX/${t}.tar`;if((await Executor.execute(`test -f "${a}" && echo "yes" || echo "no"`)).trim()!=="yes")throw new Error("Failed to decompress xz archive. The downloaded file may be incomplete or corrupted.");e("   \u2192 Extracting tar archive..."),await Executor.execute(`tar --no-same-owner -xf "${a}" -C "${n}" 2>&1`),await Executor.execute(`rm -f "${a}" "$PREFIX/${o}"`);let c=await Executor.execute(`ls "${n}" 2>/dev/null | wc -l`);if(Number.parseInt(c.trim(),10)===0)throw new Error("Extraction produced no files. The archive may be corrupted or xz decompression failed.")}else e("   \u2192 Extracting gzip archive..."),await Executor.execute(`tar --no-same-owner -xzf "$PREFIX/${o}" -C "${n}" 2>&1`),await Executor.execute(`rm -f "$PREFIX/${o}"`);if(s.isProotDistro){let m=(await Executor.execute(`ls "${n}" 2>/dev/null || echo ""`)).trim().split(`
`).filter(Boolean),c=["bin","etc","lib","lib64","usr","var","root","home","tmp","dev","proc","sys","run","opt","srv","mnt","media","sbin","boot"];if(m.length===1&&!c.includes(m[0])){e("\u{1F4C1} Fixing rootfs structure...");let h=m[0];await Executor.execute(`cd "${n}" && mv "${h}"/* . 2>/dev/null; rmdir "${h}" 2>/dev/null || true`)}}return e("\u2699\uFE0F Configuring DNS..."),system.writeText(`${n}/etc/resolv.conf`,`nameserver 8.8.8.8
nameserver 8.8.4.4`),this.config.installed[t]={installedAt:new Date().toISOString(),version:s.version},await this.saveConfig(),e(`\u2705 ${s.name} installed successfully!`),!0}catch(a){throw e(`\u274C Installation failed: ${a.message||a}`),await Executor.execute(`rm -rf "${r}" 2>/dev/null || true`),await Executor.execute(`rm -f "$PREFIX/${o}" "$PREFIX/${t}.tar" 2>/dev/null || true`),a}}async uninstall(t,e=console.log){let s=d[t];if(!s)throw new Error(`Unknown distro: ${t}`);let i=`${this.distrosPath}/${t}`;e(`\u{1F5D1}\uFE0F Uninstalling ${s.name}...`),this.config.activeDistro===t&&(this.config.activeDistro=null),await Executor.execute(`rm -rf "${i}"`),delete this.config.installed[t],await this.saveConfig(),e(`\u2705 ${s.name} uninstalled`)}async execInDistro(t,e){let s=d[t];if(!s)throw new Error(`Unknown distro: ${t}`);let i=`${this.distrosPath}/${t}/rootfs`,r=this.generateProotScript(i,e,s.shell);return await Executor.execute(r)}async startShell(t,e){let s=d[t];if(!s)throw new Error(`Unknown distro: ${t}`);if(!this.config.installed[t])throw new Error(`${s.name} is not installed`);let i=`${this.distrosPath}/${t}/rootfs`,r=this.generateProotScript(i,s.shell,s.shell);this.config.activeDistro=t,await this.saveConfig();let n=await Executor.start("sh",e,!1);return await Executor.write(n,`${r}
`),n}generateProotScript(t,e,s="/bin/sh"){return`
export LD_LIBRARY_PATH=$PREFIX
export PROOT_TMP_DIR=$PREFIX/tmp

mkdir -p "$PREFIX/tmp"

if [ -f "$NATIVE_DIR/libproot.so" ]; then
  export PROOT_LOADER="$NATIVE_DIR/libproot.so"
fi
if [ -f "$NATIVE_DIR/libproot32.so" ]; then
  export PROOT_LOADER32="$NATIVE_DIR/libproot32.so"
fi
export PROOT="$NATIVE_DIR/libproot-xed.so"

ARGS="--kill-on-exit"

for mnt in /apex /odm /product /system /system_ext /vendor /linkerconfig/ld.config.txt; do
  [ -e "$mnt" ] && ARGS="$ARGS -b $(realpath $mnt)"
done

ARGS="$ARGS -b /sdcard -b /storage -b /dev -b /data -b /proc -b /sys"
ARGS="$ARGS -b /dev/urandom:/dev/random"
ARGS="$ARGS -r ${t}"
ARGS="$ARGS -0 --link2symlink --sysvipc -L"
ARGS="$ARGS -w /root"

$PROOT $ARGS ${s} -c "${e.replace(/"/g,'\\"')}"
`}async getInstalledSize(t){let e=`${this.distrosPath}/${t}`;try{return(await Executor.execute(`du -sh "${e}" 2>/dev/null | cut -f1`)).trim()||"Unknown"}catch{return"Unknown"}}},v=x;var S=acode.require("confirm"),u=acode.require("alert"),f=acode.require("select"),R=acode.require("loader"),g={INSTALL:"distro-manager.install",UNINSTALL:"distro-manager.uninstall",OPEN_SHELL:"distro-manager.shell",LIST:"distro-manager.list",INFO:"distro-manager.info"},I=43130,y=3;function O(p){return`'${String(p).replace(/'/g,"'\\''")}'`}var w=class{constructor(){this.manager=null,this.baseUrl="",this.filesDir=""}async init(){this.filesDir=await new Promise((t,e)=>{system.getFilesDir(t,e)}),this.manager=new v(this.filesDir),await this.manager.init(),this.registerCommands()}registerCommands(){let{commands:t}=editorManager.editor;t.addCommand({name:g.INSTALL,description:"Distro Manager: Install Distribution",exec:()=>this.showInstallMenu()}),t.addCommand({name:g.UNINSTALL,description:"Distro Manager: Uninstall Distribution",exec:()=>this.showUninstallMenu()}),t.addCommand({name:g.OPEN_SHELL,description:"Distro Manager: Open Shell",exec:()=>this.showShellMenu()}),t.addCommand({name:g.LIST,description:"Distro Manager: List Distributions",exec:()=>this.showDistroList()}),t.addCommand({name:g.INFO,description:"Distro Manager: Distribution Info",exec:()=>this.showDistroInfo()})}async showInstallMenu(){let t=this.manager.getAvailableDistros().filter(i=>!i.installed);if(t.length===0){u("Distro Manager","All available distributions are already installed! \u{1F389}");return}let e=t.map(i=>[i.id,`${i.icon} ${i.name} ${i.version}`,`${i.description} (${i.size})`]),s=await f("Select Distribution to Install",e,{textTransform:!1});s&&await this.installDistro(s)}async installDistro(t){let e=d[t];if(!e)return;let s=`
      <div style="text-align: left;">
        <p><strong>${e.icon} ${e.name} ${e.version}</strong></p>
        <br>
        <p>\u{1F4E6} <strong>Size:</strong> ${e.size}</p>
        <p>\u{1F4CB} <strong>Package Manager:</strong> ${e.pkgManager}</p>
        <br>
        <p style="color: #888;">This may take a few minutes depending on your connection.</p>
      </div>
    `;if(!await S("Install Distribution",s,!0))return;let r=R.create("Installing...","",{timeout:0}),n=[],l=o=>{n.push(o),r.setMessage(o),console.log(`[DistroManager] ${o}`)};try{await this.manager.install(t,l),await this.createDistroInitScript(t,{force:!0}),r.destroy();let o=`
        <div style="text-align: center;">
          <p style="font-size: 1.2em;">${e.icon} <strong>${e.name}</strong></p>
          <p style="color: #4CAF50;">\u2713 Installed successfully!</p>
          <br>
          <p style="color: #888; font-size: 0.9em;">
            Use <strong>"Distro Manager: Open Shell"</strong><br>from the command palette to start.
          </p>
        </div>
      `;u("Installation Complete",o)}catch(o){r.destroy();let a=o.message||String(o),m=`
        <div style="text-align: left;">
          <p style="color: #F44336;">\u274C Failed to install ${e.name}</p>
          <br>
          <p><strong>Error:</strong></p>
          <p style="font-family: monospace; font-size: 0.85em; color: #888;">${a}</p>
          <br>
          <p><strong>Recent logs:</strong></p>
          <pre style="font-size: 0.8em; color: #666; overflow-x: auto;">${n.slice(-5).join("<br>")}</pre>
        </div>
      `;u("Installation Failed",m)}}async ensureDistroInitScript(t){let e=this.manager.config.installed[t],s=`${this.manager.distrosPath}/${t}/init-distro.sh`,r=`${`${this.manager.distrosPath}/${t}/rootfs`}/etc/acode-initrc`;return e?.initScriptVersion===y&&await this.manager.fileExists(s)&&await this.manager.fileExists(r)?s:this.createDistroInitScript(t,{force:!0})}async createDistroInitScript(t,{force:e=!1}={}){let s=d[t],i=`${this.manager.distrosPath}/${t}/rootfs`,r=`${this.manager.distrosPath}/${t}`,n=`${this.manager.distrosPath}/${t}/init-distro.sh`,l=`${i}/etc/acode-initrc`,o=`${r}/last-launch.log`;if(!e&&await this.manager.fileExists(n))return n;let a=s.name.toLowerCase().replace(/\s+/g,""),m=`# Acode ${s.name} Shell Configuration
export HOME=/root
export PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:/system/bin
export TERM=xterm-256color
export LANG=C.UTF-8
export SHELL=${s.shell}

# Source system profiles if they exist
[ -f /etc/profile ] && . /etc/profile
[ -f /etc/bash.bashrc ] && . /etc/bash.bashrc
[ -f ~/.bashrc ] && . ~/.bashrc

# Color prompt: user@distro:path$
PS1='\\[\\033[1;32m\\]\\u\\[\\033[0m\\]@\\[\\033[1;35m\\]${a}\\[\\033[0m\\]:\\[\\033[1;34m\\]\\w\\[\\033[0m\\]\\$ '

# Show welcome message
if [ ! -f /tmp/.motd_shown ]; then
  echo ""
  echo -e "\\033[1;36m\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\\033[0m"
  echo -e "  \\033[1;33m${s.icon} Welcome to ${s.name} in Acode!\\033[0m"
  echo -e "\\033[1;36m\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\\033[0m"
  echo ""
  echo -e "  Package Manager: \\033[1;32m${s.pkgManager}\\033[0m"
  echo ""
  touch /tmp/.motd_shown
fi

cd ~
`,c=`#!/bin/sh
export LD_LIBRARY_PATH=$PREFIX
export PROOT_TMP_DIR=$PREFIX/tmp
LOG_FILE="${o}"

log() {
  printf '%s %s\\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG_FILE"
}

: > "$LOG_FILE"
log "starting ${s.name} launcher"
log "PREFIX=$PREFIX"
log "NATIVE_DIR=$NATIVE_DIR"
log "FDROID=$FDROID"

mkdir -p "$PREFIX/tmp"
mkdir -p "$PREFIX/public"
mkdir -p "${i}/tmp"

if [ -f "$NATIVE_DIR/libproot.so" ]; then
  export PROOT_LOADER="$NATIVE_DIR/libproot.so"
fi
if [ -f "$NATIVE_DIR/libproot32.so" ]; then
  export PROOT_LOADER32="$NATIVE_DIR/libproot32.so"
fi

if [ "$FDROID" = "true" ]; then
  export PROOT="$PREFIX/libproot-xed.so"
  chmod +x $PREFIX/*
else
  if [ -e "$PREFIX/libtalloc.so.2" ] || [ -L "$PREFIX/libtalloc.so.2" ]; then
    rm -f "$PREFIX/libtalloc.so.2"
  fi
  ln -sf "$NATIVE_DIR/libtalloc.so" "$PREFIX/libtalloc.so.2"
  export PROOT="$NATIVE_DIR/libproot-xed.so"
fi

log "PROOT=$PROOT"
log "PROOT_LOADER=$PROOT_LOADER"
log "PROOT_LOADER32=$PROOT_LOADER32"

ARGS="--kill-on-exit"

for mnt in /apex /odm /product /system /system_ext /vendor /linkerconfig/ld.config.txt /linkerconfig/com.android.art/ld.config.txt /plat_property_contexts /property_contexts; do
  [ -e "$mnt" ] && ARGS="$ARGS -b $(realpath $mnt)"
done

ARGS="$ARGS -b /sdcard"
ARGS="$ARGS -b /storage"
ARGS="$ARGS -b /dev"
ARGS="$ARGS -b /data"
ARGS="$ARGS -b /dev/urandom:/dev/random"
ARGS="$ARGS -b /proc"
ARGS="$ARGS -b /sys"
ARGS="$ARGS -b $PREFIX"
ARGS="$ARGS -b $PREFIX/public:/public"
ARGS="$ARGS -b ${i}/tmp:/dev/shm"

[ -e "/proc/self/fd" ] && ARGS="$ARGS -b /proc/self/fd:/dev/fd"
[ -e "/proc/self/fd/0" ] && ARGS="$ARGS -b /proc/self/fd/0:/dev/stdin"
[ -e "/proc/self/fd/1" ] && ARGS="$ARGS -b /proc/self/fd/1:/dev/stdout"
[ -e "/proc/self/fd/2" ] && ARGS="$ARGS -b /proc/self/fd/2:/dev/stderr"

ARGS="$ARGS -r ${i}"
ARGS="$ARGS -0"
ARGS="$ARGS --link2symlink"
ARGS="$ARGS --sysvipc"
ARGS="$ARGS -L"
ARGS="$ARGS -w /root"

DISTRO_SHELL="${s.shell}"
SHELL_ARGS="-i"

if [ ! -e "${i}$DISTRO_SHELL" ] && [ -e "${i}/usr/bin/bash" ]; then
  DISTRO_SHELL="/usr/bin/bash"
fi

case "$DISTRO_SHELL" in
  */bash)
    SHELL_ARGS="--rcfile /etc/acode-initrc -i"
    ;;
esac

if [ ! -x "$PROOT" ]; then
  echo "proot executable is missing or not executable: $PROOT" >&2
  exit 126
fi

if [ ! -e "${i}$DISTRO_SHELL" ]; then
  echo "shell not found in rootfs: $DISTRO_SHELL" >&2
  log "shell not found in rootfs: $DISTRO_SHELL"
  exit 127
fi

log "DISTRO_SHELL=$DISTRO_SHELL"
log "SHELL_ARGS=$SHELL_ARGS"
log "ARGS=$ARGS"
log "executing proot"

exec $PROOT $ARGS "$DISTRO_SHELL" $SHELL_ARGS 2>> "$LOG_FILE"
`;return system.writeText(l,m),system.writeText(n,c),await new Promise((h,E)=>{system.setExec(n,!0,h,E)}),this.manager.config.installed[t]&&(this.manager.config.installed[t].initScriptVersion=y,await this.manager.saveConfig()),n}async showUninstallMenu(){let t=this.manager.getAvailableDistros().filter(o=>o.installed);if(t.length===0){u("Distro Manager","No distributions installed yet.");return}let e=await Promise.all(t.map(async o=>{let a=await this.manager.getInstalledSize(o.id);return[o.id,`${o.icon} ${o.name}`,`Size: ${a}`]})),s=await f("Select Distribution to Uninstall",e,{textTransform:!1});if(!s)return;let i=d[s],r=`
      <div style="text-align: left;">
        <p>\u26A0\uFE0F <strong>Uninstall ${i.name}?</strong></p>
        <br>
        <p style="color: #F44336;">This will permanently delete all data in this distribution including:</p>
        <ul style="color: #888; margin-left: 1em;">
          <li>Installed packages</li>
          <li>User files and configurations</li>
          <li>All custom modifications</li>
        </ul>
      </div>
    `;if(!await S("Uninstall Distribution",r,!0))return;let l=R.create("Uninstalling...","",{timeout:0});try{await this.manager.uninstall(s,o=>l.setMessage(o)),l.destroy(),u("Uninstalled",`${i.icon} ${i.name} has been removed.`)}catch(o){l.destroy(),u("Error",`Failed to uninstall: ${o.message||o}`)}}async showShellMenu(){let t=this.manager.getAvailableDistros().filter(i=>i.installed);if(t.length===0){u("No Distributions",`
        <div style="text-align: center;">
          <p>\u{1F4E6} No distributions installed</p>
          <br>
          <p style="color: #888; font-size: 0.9em;">
            Use <strong>"Distro Manager: Install Distribution"</strong><br>
            from the command palette to get started.
          </p>
        </div>
      `);return}let e=t.map(i=>[i.id,`${i.icon} ${i.name} ${i.version}`,i.active?"\u{1F7E2} active":""]),s=await f("Select Distribution",e,{textTransform:!1});s&&await this.openTerminal(s)}async openTerminal(t){if(d[t])try{await this.ensureDistroInitScript(t),await this.startDistroServer(t)||console.warn("[DistroManager] Failed to start PTY server")}catch(s){console.error("[DistroManager] Failed to open terminal:",s),acode.alert("Error",`Failed to start shell: ${s.message||s}`)}}async startDistroServer(t){let e=await this.ensureDistroInitScript(t),s=I+Object.keys(d).indexOf(t);try{if(await this.checkServerRunning(s))return console.log(`[DistroManager] Server already running on port ${s}`),await this.showTerminalOptions(t,s),s;let r=`${this.filesDir}/axs`;if(!await this.manager.fileExists(r))return acode.alert("AXS Not Found",`
          <div style="text-align: left;">
            <p>\u26A0\uFE0F <strong>AXS Server Not Found</strong></p>
            <br>
            <p style="color: #888;">
              The PTY server binary is not installed.<br><br>
              Please open Acode's built-in terminal first to install the required components.
            </p>
          </div>
        `),null;await new Promise((c,h)=>{system.setExec(r,!0,c,h)}),await new Promise((c,h)=>{system.setExec(e,!0,c,h)});let l=await Executor.start("sh",(c,h)=>{console.log(`[DistroManager AXS] ${c}: ${h}`)}),a=`
chmod +x "$PREFIX/axs" ${O(e)}
LINKER="/system/bin/linker64"
ARCH="$(uname -m)"
if [ "$ARCH" != "aarch64" ] && [ "$ARCH" != "x86_64" ]; then
  LINKER="/system/bin/linker"
fi
exec "$LINKER" "$PREFIX/axs" -p ${s} -c "sh ${e}"
`;return await Executor.write(l,`${a}
`),await new Promise(c=>setTimeout(c,3e3)),await this.checkServerRunning(s)?(this.manager.config.activeDistro=t,await this.manager.saveConfig(),await this.showTerminalOptions(t,s),s):(console.warn("[DistroManager] Server may not have started correctly"),await this.showTerminalOptions(t,s),s)}catch(i){throw console.error("[DistroManager] Failed to start server:",i),i}}async showTerminalOptions(t,e){let s=d[t],i=acode.require("acodex"),r=acode.require("terminal"),n=[["acodex","\u{1F5A5}\uFE0F Open in AcodeX Terminal","Connect using AcodeX plugin (recommended)"],["builtin","\u{1F4DF} Open in Built-in Terminal","Use Acode terminal UI directly"],["log","\u{1F4C4} Show Launch Log","View the last distro startup log"],["info","\u2139\uFE0F Show Server Info","View connection details only"]];i||(n[0][2]="\u26A0\uFE0F AcodeX plugin not installed"),r||(n[1][2]="\u26A0\uFE0F Built-in terminal not available");let l=await f("Terminal Option",n,{textTransform:!1});if(l)if(l==="acodex"){if(!i){let o=`
          <div style="text-align: left;">
            <p>\u26A0\uFE0F <strong>AcodeX Not Found</strong></p>
            <br>
            <p style="color: #888;">
              The AcodeX terminal plugin is not installed.<br><br>
              Please install AcodeX from the plugin store to use this feature.
            </p>
            <br>
            <p style="font-size: 0.9em;">
              <strong>Server is still running on port:</strong> <code>${e}</code>
            </p>
          </div>
        `;acode.alert("AcodeX Not Found",o);return}try{i.isTerminalOpened()&&(i.closeTerminal(),await new Promise(o=>setTimeout(o,300))),await i.openTerminal(270,e)}catch(o){console.error("[DistroManager] Failed to open AcodeX:",o),acode.alert("Error",`Failed to connect AcodeX: ${o.message||o}`)}}else if(l==="builtin"){if(!r){acode.alert("Error","Built-in terminal is not available.");return}try{let o=await this.createDistroSession(e);await r.create({name:`${s.icon} ${s.name}`,port:e,pid:o}),this.manager.config.activeDistro=t,await this.manager.saveConfig()}catch(o){console.error("[DistroManager] Built-in terminal failed:",o),acode.alert("Error",`Failed to open built-in terminal: ${o.message||o}`)}}else if(l==="log")await this.showLaunchLog(t);else{let o=`
        <div style="text-align: left;">
          <p>${s.icon} <strong>${s.name}</strong> PTY server running</p>
          <br>
          <p><strong>Port:</strong> <code>${e}</code></p>
          <br>
          <p><strong>Connect using:</strong></p>
          <ul style="margin-left: 1em; color: #888;">
            <li>AcodeX terminal plugin (recommended)</li>
            <li>Any WebSocket terminal client</li>
          </ul>
          <br>
          <p style="font-size: 0.85em; color: #666;">
            <strong>WebSocket:</strong> <code>ws://localhost:${e}/terminals/&lt;pid&gt;</code><br>
            <strong>Create session:</strong> <code>POST http://localhost:${e}/terminals</code>
          </p>
        </div>
      `;acode.alert(`${s.icon} Server Running`,o)}}async showLaunchLog(t){let e=d[t],s=`${this.manager.distrosPath}/${t}/last-launch.log`,i="";try{i=await this.manager.fileExists(s)?await Executor.BackgroundExecutor.execute(`cat "${s}"`):"No launch log has been written yet."}catch(n){i=`Failed to read launch log: ${n.message||n}`}let r=String(i).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");u(`${e.icon} ${e.name} Launch Log`,`<pre style="text-align:left; white-space:pre-wrap; font-size:0.8em; max-height:60vh; overflow:auto;">${r}</pre>`)}async createDistroSession(t){let e=await new Promise((s,i)=>{cordova.plugin.http.sendRequest(`http://localhost:${t}/terminals`,{method:"POST",responseType:"text",serializer:"json",data:{cols:80,rows:24}},s,r=>i(new Error(r.error||"Failed to create session")))});if(e.status<200||e.status>=300)throw new Error(`Failed to create session: HTTP ${e.status}`);return e.data.trim()}async checkServerRunning(t){try{return(await fetch(`http://localhost:${t}/`,{method:"GET",signal:AbortSignal.timeout(1e3)})).ok}catch{return!1}}async showDistroList(){let t=this.manager.getAvailableDistros(),e=t.filter(r=>r.installed),s=t.filter(r=>!r.installed),i='<div style="text-align: left;">';if(i+="<p><strong>\u{1F4E6} Installed:</strong></p>",e.length>0){i+='<ul style="margin-left: 1em; margin-bottom: 1em;">';for(let r of e){let n=await this.manager.getInstalledSize(r.id);i+=`<li>${r.icon} ${r.name} ${r.version} <span style="color: #888;">(${n})</span></li>`}i+="</ul>"}else i+='<p style="color: #888; margin-left: 1em;">None</p><br>';i+="<p><strong>\u{1F4E5} Available:</strong></p>",i+='<ul style="margin-left: 1em;">';for(let r of s)i+=`<li>${r.icon} ${r.name} ${r.version} <span style="color: #888;">(${r.size})</span></li>`;i+="</ul></div>",u("Distributions",i)}async showDistroInfo(){let e=this.manager.getAvailableDistros().map(a=>[a.id,`${a.icon} ${a.name}`,a.installed?"\u2713 Installed":"Not installed"]),s=await f("Select Distribution",e,{textTransform:!1});if(!s)return;let i=this.manager.getDistroInfo(s),r="N/A";i.installed&&(r=await this.manager.getInstalledSize(s));let n=i.installed?"#4CAF50":"#888",l=i.installed?`\u2705 Installed (${r})`:"\u274C Not installed",o=`
      <div style="text-align: left;">
        <p style="font-size: 1.2em;">${i.icon} <strong>${i.name}</strong> ${i.version}</p>
        <p style="color: #888; margin-bottom: 1em;">${i.description}</p>
        
        <table style="width: 100%; font-size: 0.9em;">
          <tr><td style="color: #888;">Package Manager</td><td><strong>${i.pkgManager}</strong></td></tr>
          <tr><td style="color: #888;">Download Size</td><td>${i.size}</td></tr>
          <tr><td style="color: #888;">Status</td><td style="color: ${n};">${l}</td></tr>
          ${i.active?'<tr><td style="color: #888;">State</td><td style="color: #4CAF50;">\u{1F7E2} Active</td></tr>':""}
        </table>
        
        <p style="margin-top: 1em; font-size: 0.8em; color: #666;">
          <strong>Path:</strong> ${i.installPath}
        </p>
      </div>
    `;u("Distribution Info",o)}destroy(){let{commands:t}=editorManager.editor;Object.values(g).forEach(e=>{t.removeCommand(e)})}};if(window.acode){let p=new w;acode.setPluginInit($.id,async t=>{t.endsWith("/")||(t+="/"),p.baseUrl=t,await p.init()}),acode.setPluginUnmount($.id,()=>{p.destroy()})}})();
